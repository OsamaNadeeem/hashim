<?php 
include("../header.php");

?>
<!doctype html>
    <html lang="en">
    <head>
      <meta charset="UTF-8">
      <title>database connections</title>
    <style>
body {
background:url(images/bg.jpg);


font-family:Tahoma, Geneva, sans-serif;
}
th {
height:40px;
color:#000;
font-weight:bold;
}
td {
color:#FFF;
height:30px;
}
a {
color:#FFF;
text-decoration:none;
}
a:hover {
color:#FFF;
text-decoration:underline;
}
</style>
    </head>
    <body>
    <h1>Welcome <?php echo $login_session; ?></h1> 
      <?php
      

      //execute the SQL query and return records
	  $agentname = $login_session;
	  $sql = "SELECT id, username, active FROM users";
      $result = mysqli_query($db,$sql) or die("Error: ".mysqli_error($db));
      ?>
      <table border="2" style= "background-color: #84ed86; color: #761a9b; margin: 0 auto;" >
      <thead>
        <tr>
          <th>ID</th>
          <th>User Name</th>
		  <th>Active</th>                                    
          <td></td>
        </tr>
      </thead>
      <tbody>
        <?php
          while( $row = mysqli_fetch_assoc($result) ){
            echo
            "<tr>
              <td>{$row['id']}</td>
              <td>{$row['username']}</td>
			  <td>{$row['active']}</td>
            </tr>\n";
          }
        ?>
      </tbody>
    </table>
    <div class="container">
    <form class="form-signin" method="POST">
     <?php
    
		if(isset($_POST['submit'])) {
			$id = isset($_POST['id']) ? $_POST['id'] : '';
			$query = "UPDATE users SET active = '1' WHERE users.id = '$id'";
			$result = mysqli_query($db,$query) or die("Error: ".mysqli_error($db));
			if($result === TRUE){
				$smsg = "Agent Account Activated!";
				header( "refresh:5; url=index.php" );
			}
			else $fmsg = "Agent Account couldnt be Activated! Try Again";
			}
	?>
    <label >Enter Agent ID to Activate</label>
    <input type="text" name="id" class="form-control" placeholder="ID" required autofocus>
    <button class="btn btn-lg btn-primary btn-block" type="submit" name="submit" >Submit</button>
    <a class="btn btn-lg btn-primary btn-block" href="view-customers.php">View Customers</a>
    <a class="btn btn-lg btn-primary btn-block" href="../admin/index.php">Back</a>
    <?php if(isset($smsg)){ ?><div class="alert alert-success" role="alert"> <?php echo $smsg; ?> </div><?php } ?>
    <?php if(isset($fmsg)){ ?><div class="alert alert-danger" role="alert"> <?php echo $fmsg; ?> </div><?php } ?>
    </form>
    </div>
    </body>
    </html>