<?php 
include("../header.php");

?>
<!doctype html>
    <html lang="en">
    <head>
      <meta charset="UTF-8">
      <title>Delete Received Transactions</title>
      <link href="../style/style.css" rel="stylesheet" type="text/css" />
    </head>
    <body style="background-color:#CCC;">
    <h2 align="center" class="input-group form-signin-heading" style="margin-left:100px;">Delete Received Transactions</h2>
      <?php
      

      //execute the SQL query and return records
	  $agentname = $login_session;
	  $sql = "SELECT * FROM receivedtransaction";
      $result = mysqli_query($db,$sql) or die("Error: ".mysqli_error($db));
      ?>
      <div>
      <table align="center">
      <thead>
        <tr>
          <th>ID</th>
          <th>Sender Name</th>
          <th>Sender Mobile Number</th>
          <th>Sender Location</th>
          <th>Sender Agent</th>
          <th>Receiver Agent</th>
          <th>Rate</th>
          <th>Amount Received</th>    
          <th>Mode of Payment</th>                                    
        </tr>
      </thead>
      <tbody>
        <?php
          while( $row = mysqli_fetch_assoc($result) ){
            echo
            "<tr>
              <td>{$row['id']}</td>
              <td>{$row['sendername']}</td>
              <td>{$row['sendermobnumber']}</td>
              <td>{$row['senderloc']}</td>
              <td>{$row['senderagent']}</td>
              <td>{$row['receiveragent']}</td> 
			  <td>{$row['rate']}</td>
			  <td>{$row['amount']}</td>			  
			  <td>{$row['mode']}</td>
            </tr>\n";
          }
        ?>
      </tbody>
    </table>
    </div>
    <div class="container">
    <form class="form-signin" method="POST">
    
    <?php
    
		if(isset($_POST['submit'])) {
			$id = isset($_POST['id']) ? $_POST['id'] : '';
			$query = "DELETE FROM receivedtransaction WHERE `id`=$id";
			$result = mysqli_query($db,$query) or die("Error: ".mysqli_error($db));
			if($result === TRUE){
				$smsg = "Transaction Deleted Successfully! Please wait while we Redirect you to Index Page.";
				header( "refresh:5; url=index.php" );
			}
			else $fmsg = "Transaction couldnt be Deleted! Try Again";
			}
	?>
    
    <div>
    <div class="input-group">
    <h5 class="form-signin-heading"><b>Enter Transaction ID to Delete</b></h5>
    
        <input type="text" name="id" placeholder="ID" required>
        <button type="submit" name="submit" >Submit</button>
        <a href="../admin/view-received-transaction.php">Cancel</a>
        <a href="view-transaction.php">View Transaction</a>
        
        <?php if(isset($smsg)){ ?><div class="alert alert-success" role="alert"> <?php echo $smsg; ?> </div><?php } ?>
        <?php if(isset($fmsg)){ ?><div class="alert alert-danger" role="alert"> <?php echo $fmsg; ?> </div><?php } ?>
    </div>
    </div>
    </form>
    </div>
    </body>
    </html>
    <?php include("../footer.php"); ?>