<?php
	include('../header.php');
	$id=$_GET['id'];
?>
<html>
<head>
<title>Change Password</title>
<script>
function validatePassword() {
var currentPassword,newPassword,confirmPassword,output = true;

currentPassword = document.frmChange.currentPassword;
newPassword = document.frmChange.newPassword;
confirmPassword = document.frmChange.confirmPassword;

if(!currentPassword.value) {
currentPassword.focus();
document.getElementById("currentPassword").innerHTML = "required";
output = false;
}
else if(!newPassword.value) {
newPassword.focus();
document.getElementById("newPassword").innerHTML = "required";
output = false;
}
else if(!confirmPassword.value) {
confirmPassword.focus();
document.getElementById("confirmPassword").innerHTML = "required";
output = false;
}
if(newPassword.value != confirmPassword.value) {
newPassword.value="";
confirmPassword.value="";
newPassword.focus();
document.getElementById("confirmPassword").innerHTML = "not same";
output = false;
} 	
return output;
}
</script>
<link rel="stylesheet" type="text/css" href="../style/style.css" />
</head>
<body style="background-color:#CCC;">
    <h2 align="center" class="input-group form-signin-heading" style="margin-left:100px;">Change Password</h2>
    <div class="container">
<form name="frmChange" method="post" action="" onSubmit="return validatePassword()">

<?php

$username = $login_session;
if($id)
{
$var = $id;
$result5 = mysqli_query($db,"SELECT * from users WHERE id=$var") or die("Error: ".mysqli_error($db));
		$row5=mysqli_fetch_array($result5);
		$username6=$row5["username"];

}

	if(count($_POST)>0) {
		$editid = $id;
        
		$result = mysqli_query($db,"SELECT * from users WHERE id='$editid'") or die("Error: ".mysqli_error($db));
		$row=mysqli_fetch_array($result);
		$password=$row["password"];
		//echo $password;
		$currentPassword = isset($_POST['currentPassword']) ? $_POST['currentPassword'] : '';
		$newPassword = isset($_POST['newPassword']) ? $_POST['newPassword'] : '';
		if($currentPassword == $password) {
			mysqli_query($db,"UPDATE users set password='$newPassword' WHERE id='$editid'");
			$message = "Password Changed. Please wait while we Redirect you to Index Page.";
			header( "refresh:5; url=../admin/index.php" );
		} 
		else $message = "Current Password is not correct";
	}
?>
<div style="width:500px;">
<div class="message"><?php if(isset($message)) { echo $message; } ?></div>
<table>
<tr>
<td width="40%"><label>Current Password</label></td>
<td width="60%"><input type="password" name="currentPassword" class="txtField"/><span id="currentPassword"  class="required"></span></td>
</tr>
<tr>
<td><label>New Password</label></td>
<td><input type="password" name="newPassword" class="txtField"/><span id="newPassword" class="required"></span></td>
</tr>
<tr>
<td><label>Confirm Password</label></td>
<td><input type="password" name="confirmPassword" class="txtField"/><span id="confirmPassword" class="required"></span></td>
</tr>
<tr>
<td colspan="2"><input type="submit" name="submit" value="Change" ></td>
</tr>
<tr>
<td colspan="2"><a href="../admin/index.php">Back</a></td>
</tr>
</table>
</div>
</div>
</form>
</div>
    </body>
    </html>
    <?php include("../footer.php"); ?>