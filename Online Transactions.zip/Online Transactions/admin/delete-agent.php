<?php 
include("../header.php");

?>
<!doctype html>
    <html lang="en">
    <head>
      <meta charset="UTF-8">
      <title>Deactivate Agent</title>
      <link href="../style/style.css" rel="stylesheet" type="text/css" />
    </head>
    <body style="background-color:#CCC;">
    <h2 align="center" class="input-group form-signin-heading" style="margin-left:100px;">Deactivate Agent</h2>
       <?php
      

      //execute the SQL query and return records
	  $agentname = $login_session;
	  $sql = "SELECT id, username, active FROM users";
      $result = mysqli_query($db,$sql) or die("Error: ".mysqli_error($db));
      ?>
      <div class="container">
      <table align="center">
      <thead>
        <tr>
          <th>ID</th>
          <th>User Name</th>
		  <th>Active</th>                                    
        </tr>
      </thead>
      <tbody>
	  <?php
          while( $row = mysqli_fetch_assoc($result) ){
            echo
            "<tr>
              <td>{$row['id']}</td>
              <td>{$row['username']}</td>
			  <td>{$row['active']}</td>
            </tr>\n";
          }
        ?>
      </tbody>
    </table>
    </div>
    <div class="container">
    <form class="form-signin" method="POST">
    
    <?php
    
		if(isset($_POST['submit'])) {
			$id = isset($_POST['id']) ? $_POST['id'] : '';
			$query = "UPDATE users SET active = '0' WHERE users.id = '$id'";
			$result = mysqli_query($db,$query) or die("Error: ".mysqli_error($db));
			if($result === TRUE){
				$smsg = "Agent Account Deactivated! Please wait while we Redirect you to Index Page.";
				header( "refresh:5; url=index.php" );
			}
			else $fmsg = "Agent Account couldnt be Deactivated! Try Again";
			}
	?>
    
    <div>
    <div class="input-group">
    <h5 class="form-signin-heading"><b>Enter Agent ID to Deactivate</b></h5>
    
        <input type="text" name="id" placeholder="ID" required>
        <button type="submit" name="submit" >Submit</button>
        <a href="view-customers.php">View Customers</a>
        <a href="../admin/index.php">Back</a>
        <?php if(isset($smsg)){ ?><div class="alert alert-success" role="alert"> <?php echo $smsg; ?> </div><?php } ?>
        <?php if(isset($fmsg)){ ?><div class="alert alert-danger" role="alert"> <?php echo $fmsg; ?> </div><?php } ?>
    </div>
    </div>
    </form>
    </div>
    </body>
    </html>
    <?php include("../footer.php"); ?>