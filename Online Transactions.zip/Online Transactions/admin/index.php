<html>
   
   <head>
      <title>Admin Page</title>
      <link href="../style/style.css" rel="stylesheet" type="text/css">
   </head>   
<body bgcolor = "#FFFFFF">
<?php
   include('../header.php');
?>
<center> 
<div id="content" style="margin-top: 20px;">
   <a href="register-agent.php">Create A User</a>
   <a href="view-agents.php">View Agents</a>
   <a href="view-customers.php">View Customers</a>
   <a href="view-transaction.php">View Sent Transactions</a>
   <a href="view-received-transaction.php">View Received Transactions</a>
   <a href="password-change.php">Change Password</a>
   <a href="../logout.php">Log Out</a>
  </div>
  </center> 
<?php
   include('../footer.php');
?>
</body>
</html>