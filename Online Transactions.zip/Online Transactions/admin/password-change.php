<?php
  include('../header.php');
?>
       
<html>
<head>
<title>Change Password</title>
<link href="../style/style.css" rel="stylesheet" type="text/css" />
</head>
<body style="background-color:#CCC !important">
<h2 align="center" class="input-group form-signin-heading" style="margin-left:100px;">User Details</h2>
<div class="container">

    
        
        <select id="existingcust" name="to_user" class="form-control" onChange="location = this.options[this.selectedIndex].value;" required>
            <option value="pick" selected disabled>Select User</option>
            <?php
            $sql = mysqli_query($db, "SELECT * From users");
            $row = mysqli_num_rows($sql);
            while ($row = mysqli_fetch_array($sql)){
            echo "<option value='change_password.php?id=". $row['id'] ."'>" ." ". $row['username']."</option>" ;
            }
            ?>
        </select>
                <a href="index.php">Back</a>
              </form>
        </div>

   </body>
</html> 