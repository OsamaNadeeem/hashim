<?php
include("../header.php");
$id=$_GET['id'];
$u=$_GET['u'];
$msg="";
error_reporting(E_ALL);

if(isset($_POST['update'])) {
    if($u==1) {
        // If the values are posted, insert them into the database.
        $firstname = isset($_POST['firstname']) ? $_POST['firstname'] : '';
        $middlename = isset($_POST['middlename']) ? $_POST['middlename'] : '';
        $lastname = isset($_POST['lastname']) ? $_POST['lastname'] : '';
        $username = isset($_POST['username']) ? $_POST['username'] : '';
        $city = isset($_POST['city']) ? $_POST['city'] : '';
        //$state = isset($_POST['state']) ? $_POST['state'] : '';
        $country = isset($_POST['country']) ? $_POST['country'] : '';
        $mobnumber1 = isset($_POST['mobnumber1']) ? $_POST['mobnumber1'] : '';
        $mobnumber2 = isset($_POST['mobnumber2']) ? $_POST['mobnumber2'] : 'NULL';
        $email = isset($_POST['email']) ? $_POST['email'] : 'NULL';
        $agenttype = isset($_POST['agenttype']) ? $_POST['agenttype'] : 'NULL';
        $query1 = "UPDATE `agents` SET `firstname` = '$firstname',`middlename` = '$middlename', `lastname` = '$lastname', `username` = '$username', `city` = '$city', `country` = '$country', `mobnumber1` = '$mobnumber1', `mobnumber2` = '$mobnumber2', `email` = '$email', `agenttype` = '$agenttype' WHERE `agents`.`id` = $id;
	";
        $result1 = mysqli_query($db, $query1) or die("Error: ".mysqli_error($db));
        if($result1===TRUE) {
            header("Location: view-agents.php");
        } else {
            $msg = "Coudln't Update the Details! Try Again!";
        }
    } else if($u==2) {
        $firstname = isset($_POST['firstname']) ? $_POST['firstname'] : '';
        $firstname = isset($_POST['middlename']) ? $_POST['middlename'] : '';
        $lastname = isset($_POST['lastname']) ? $_POST['lastname'] : '';
        $city = isset($_POST['city']) ? $_POST['city'] : '';
        //$state = isset($_POST['state']) ? $_POST['state'] : '';
        $country = isset($_POST['country']) ? $_POST['country'] : '';
        $mobnumber1 = isset($_POST['mobnumber1']) ? $_POST['mobnumber1'] : '';
        $mobnumber2 = isset($_POST['mobnumber2']) ? $_POST['mobnumber2'] : 'NULL';
        $email = isset($_POST['email']) ? $_POST['email'] : 'NULL';
        $bankdetails = isset($_POST['bankdetails']) ? $_POST['bankdetails'] : 'NULL';
        $agentname = isset($_POST['agentname']) ? $_POST['agentname'] : 'NULL';
        $query2 = "UPDATE `customers` SET `firstname` = '$firstname',`middlename` = '$middlename', `lastname` = '$lastname', `city` = '$city', `country` = '$country', `mobnumber1` = '$mobnumber1', `mobnumber2` = '$mobnumber2', `email` = '$email', `bankdetails` = '$bankdetails', `agentname` = '$agentname' WHERE `customers`.`id` = $id;";
        $result2 = mysqli_query($db, $query2) or die("Error: ".mysqli_error($db));
        if($result2===TRUE) {
            header("Location: view-customers.php");
        } else {
            $msg = "Coudln't Update the Details! Try Again!";
        }

    }else {
        $sendername = isset($_POST['sendername']) ? $_POST['sendername'] : '';
        $amount = isset($_POST['amount']) ? $_POST['amount'] : '';
        $agentname = isset($_POST['agentname']) ? $_POST['agentname'] : '';
        $location = isset($_POST['location']) ? $_POST['location'] : '';
        $receivername = isset($_POST['receivername']) ? $_POST['receivername'] : '';
        $receivermobnumber = isset($_POST['receivermobnumber']) ? $_POST['receivermobnumber'] : '';
        $receiveragent = isset($_POST['receiveragent']) ? $_POST['receiveragent'] : '';
        $receiverlocation = isset($_POST['receiverlocation']) ? $_POST['receiverlocation'] : '';
        $mode = isset($_POST['mode']) ? $_POST['mode'] : '';
        $rate = isset($_POST['rate']) ? $_POST['rate'] : '';
        $amounttsz = isset($_POST['amounttsz']) ? $_POST['amounttsz'] : '';
        $paymentstatus = isset($_POST['paymentstatus']) ? $_POST['paymentstatus'] : '';
        $query3 = "UPDATE `transaction` SET `sendername`='$sendername', `amount` = '$amount', `agentname` = '$agentname', `location` = '$location', `receivername` = '$receivername', `receivermobnumber` = '$receivermobnumber ', `receiveragent` = '$receiveragent', `receiverlocation` = '$receiverlocation ',  `mode` = '$mode' ,`rate` = '$rate' ,`amounttsz` ='$amounttsz', `paymentstatus`='$paymentstatus' WHERE `id` = $id;";
        $result3 = mysqli_query($db, $query3) or die("Error: ".mysqli_error($db));
        if($result3===TRUE) {
            header("Location: view-transaction.php");
        } else {
            $msg = "Coudln't Update the Details! Try Again!";
        }
    }
}
?>
    <!doctype html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <title>Update Details</title>
    </head>
    <body style="background-color:#CCC;">
    <h2 align="center" class="input-group form-signin-heading" style="margin-left:100px;">Update Details</h2>
    <?php

    //execute the SQL query and return records
    $agentname = $login_session;
    if($u==1)
        $sql = "SELECT * FROM agents WHERE id = '$id'";
    else if($u==2)
        $sql = "SELECT * FROM customers WHERE id = '$id'";
    else
        $sql="SELECT * FROM transaction WHERE id = '$id'";
    $result = mysqli_query($db,$sql) or die("Error: ".mysqli_error($db));
    ?>
    <div>
        <div><?php echo $msg; ?></div>
        <form method="post">
            <table align="center" style="width:auto !important; padding:3 !important;">
                <?php if($u==1) { ?>
                    <thead>
                    <tr>
                        <th>ID</th>
                        <th>First Name</th>
                        <th>Middle Name</th>
                        <th>Last Name</th>
                        <th>Username</th>
                        <th>City</th>
                        <th>Country</th>
                        <th>Mobile Number</th>
                        <th>Alternate Mobile Number</th>
                        <th>Email</th>
                        <th>Agent Type</th>
                        <th>Active</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php
                    while( $row = mysqli_fetch_assoc($result) ){
                        ?>
                        <tr>
                            <td><?php echo $row['id']; ?></td>
                            <td><input type="text" name="firstname" style="width:100px" value="<?php echo $row['firstname']; ?>" style="padding:0 !important; margin:0 !important" ></td>
                            <td><input type="text" name="middlename" style="width:100px" value="<?php echo $row['middlename']; ?>" style="padding:0 !important; margin:0 !important" ></td>
                            <td><input type="text" name="lastname" style="width:100px" value="<?php echo $row['lastname']; ?>" ></td>
                            <td><input type="text" name="username" style="width:100px" value="<?php echo $row['username']; ?>" ></td>
                            <td><input type="text" name="city" style="width:100px" value="<?php echo $row['city'] ; ?>" ></td>
                            <td><input type="text" name="country" style="width:100px" value="<?php echo $row['country']; ?>" ></td>
                            <td><input type="text" name="mobnumber1" style="width:140px" value="<?php echo $row['mobnumber1'] ; ?>" ></td>
                            <td><input type="text" name="mobnumber2" style="width:140px" value="<?php echo $row['mobnumber2'] ; ?>" ></td>
                            <td><input type="text" name="email" style="width:250px" value="<?php echo $row['email'] ; ?>" ></td>
                            <td><select style="width:200px;" name="agenttype">
                                    <?php if($row['agenttype'] == "Super Agent") { ?>
                                        <option value="Principal Agent">Principal Agent</option>
                                        <option value="Super Agent">Super Agent</option>
                                        <option value="Sub Agent" selected>Sub Agent</option>
                                        <option value="Dataentry" selected>Dataentry</option>
                                    <?php } else {?>
                                        <option value="Principal Agent">Principal Agent</option>
                                        <option value="Super Agent">Super Agent</option>
                                        <option value="Sub Agent" selected>Sub Agent</option>
                                        <option value="Dataentry" selected>Dataentry</option>
                                    <?php } ?>
                                </select>
                            </td>
                            <td><?php echo $row['active'] ; ?></td>
                        </tr>
                    <?php } ?>
                    </tbody>
                <?php } else if($u==2) { ?>
                    <thead>
                    <tr>
                        <th>ID</th>
                        <th>First Name</th>
                        <th>Middle Name</th>

                        <th>Last Name</th>
                        <th>City</th>
                        <th>Country</th>
                        <th>Mobile Number</th>
                        <th>Alternate Mobile Number</th>
                        <th>Email</th>
                        <th>Bank Details</th>
                        <th>Agent Name</th>
                        <th>Active</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php
                    while( $row = mysqli_fetch_assoc($result) ){
                        ?>
                        <tr>
                            <td><?php echo $row['id']; ?></td>
                            <td><input type="text" name="firstname" style="width:100px" value="<?php echo $row['firstname']; ?>" ></td>
                            <td><input type="text" name="middlename" style="width:100px" value="<?php echo $row['middlename']; ?>" ></td>
                            <td><input type="text" name="lastname" style="width:100px" value="<?php echo $row['lastname']; ?>" ></td>
                            <td><input type="text" name="city" style="width:100px" value="<?php echo $row['city']; ?>" ></td>
                            <td><input type="text" name="country" style="width:100px" value="<?php echo $row['country']; ?>" ></td>
                            <td><input type="text" name="mobnumber1" style="width:140px" value="<?php echo $row['mobnumber1']; ?>" ></td>
                            <td><input type="text" name="mobnumber2" style="width:140px" value="<?php echo $row['mobnumber2']; ?>" ></td>
                            <td><input type="text" name="email" style="width:250px" value="<?php echo $row['email']; ?>" ></td>
                            <td><input type="text" name="bankdetails" style="width:200px" value="<?php echo $row['bankdetails']; ?>" ></td>
                            <td><input type="text" name="agentname" style="width:100px" value="<?php echo $row['agentname']; ?>" ></td>
                            <td><?php echo $row['active']; ?></td>
                            "?>
                        </tr>
                    <?php } ?>

                    </tbody>
                <?php } else { ?>
                    <thead>
                    <tr>
                        <th>Sender Name</th>
                        <th>Amount in AED</th>
                        <th>Agent Name</th>
                        <th>Location</th>
                        <th>Receiver Name</th>
                        <th>Receiver Mobile Number</th>
                        <th>Receiver Agent</th>
                        <th>Receiver Location</th>

                        <th>Mode of Payment</th>
                        <th>Rate</th>
                        <th>Amount in TZS</th>
                        <th>Payment Status</th>

                    </tr>
                    </thead>
                    <tbody>
                    <?php
                    while( $row = mysqli_fetch_assoc($result) ){
                        ?>
                        <tr>

                            <td><input type="text" name="sendername" style="width:100px" value="<?php echo $row['sendername']; ?>" ></td>
                            <td><input type="text" name="amount" style="width:100px" value="<?php echo $row['amount']; ?>" ></td>
                            <td><input type="text" name="agentname" style="width:100px" value="<?php echo $row['agentname']; ?>" ></td>
                            <td><input type="text" name="location" style="width:100px" value="<?php echo $row['location']; ?>" ></td>
                            <td><input type="text" name="receivername" style="width:140px" value="<?php echo $row['receivername']; ?>" ></td>
                            <td><input type="text" name="receivermobnumber" style="width:140px" value="<?php echo $row['receivermobnumber']; ?>" ></td>
                            <td><input type="text" name="receiveragent" style="width:250px" value="<?php echo $row['receiveragent']; ?>" ></td>
                            <td><input type="text" name="receiverlocation" style="width:200px" value="<?php echo $row['receiverlocation']; ?>" ></td>
                            <td><input type="text" name="mode" style="width:200px" value="<?php echo $row['mode']; ?>" ></td>
                            <td><input type="text" name="rate" style="width:200px" value="<?php echo $row['rate']; ?>" ></td>
                            <td><input type="text" name="amounttsz" style="width:200px" value="<?php echo $row['amounttsz']; ?>" ></td>
                            <td><input type="text" name="paymentstatus" style="width:200px" value="<?php echo $row['paymentstatus']; ?>" ></td>

                        </tr>
                        </tr>
                    <?php } ?>
                    </tbody>
                <?php } ?>


            </table>
            <button type="update" value="Update" name="update" style="margin-left:500px;">Update</button>
        </form>
    </div>
    <div id="content">
        <div class="input-group">
            <?php if($u==1) { ?>
                <a href="../admin/view-agents.php">Back</a>
            <?php } else if($u==2) { ?>
                <a href="../admin/view-customers.php">Back</a>
            <?php } else  { ?>
                <a href="../admin/view-transaction.php">Back</a>
            <?php } ?>
        </div>
    </div>
    </body>
    </html>
<?php include("../footer.php"); ?>