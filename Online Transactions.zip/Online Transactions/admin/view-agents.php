<?php 
error_reporting( E_ALL );
include("../header.php");
?>
<!doctype html>
    <html lang="en">
    <head>
      <meta charset="UTF-8">
      <title>Agents</title>
    <link href="../style/style.css" rel="stylesheet" type="text/css">
    </head>
    <body style="background-color:#CCC;">
    <h2 align="center" class="input-group form-signin-heading" style="margin-left:100px;">View Agents</h2> 
      <?php
      

      //execute the SQL query and return records
	  $agentname = $login_session;
	  $sql = "SELECT * FROM agents";
      $result = mysqli_query($db,$sql) or die("Error: ".mysqli_error($db));
      ?>
      <div>
      <table align="center">
      <thead>
        <tr>
          <th>ID</th>
          <th>First Name</th>
          <th>Middle Name></th>
           <th>Last Name</th>
		  <th> User Name</th>
          <th>City</th>
          <th>Country</th>
          <th>Mobile Number</th>
          <th>Alternate Mobile Number</th>
          <th>Email</th>
          <th>Agent Type</th>
		  <th>Active</th> 
          <th colspan="3">Action</th>                                   
        </tr>
      </thead>
      <tbody>
        <?php
          while( $row = mysqli_fetch_assoc($result) ){
            echo
            "<tr>
              <td>{$row['id']}</td>
              <td>{$row['firstname']}</td>
              <td>{$row['middlename']}</td>
              <td>{$row['lastname']}</td>
<td>{$row['username']}</td>
              <td>{$row['city']}</td>
              
			  <td>{$row['country']}</td>
			  <td>{$row['mobnumber1']}</td>
			  <td>{$row['mobnumber2']}</td>
			  <td>{$row['email']}</td>
			  <td>{$row['agenttype']}</td>
			  <td>{$row['active']}</td>
"?>
        <td><a id="action" href="deactivate.php?id=<?php echo $row['id']; ?>&f=3" onclick="return confirm('Are you sure?')">Delete</a></td>
        <td><a id="action" href="update.php?id=<?php echo $row['id']; ?>&u=1">Update</a></td>
        <td><?php if($row['active'] == 0) { ?><a id="action" href="deactivate.php?id=<?php echo $row['id']; ?>&f=1">Activate</a>
        <?php } else { ?><a id="action" href="deactivate.php?id=<?php echo $row['id']; ?>&f=2">Deactivate</a><?php } ?></td>
        </tr>
 <?php " " ."\n            ";
          }
  ?>
      </tbody>
    </table>
    </div>
    <div id="content">
    <div class="input-group">
    <a href="view-customers.php">View Customers</a>
    <a href="../admin/index.php">Back</a>
    </div>
    </div>
    </body>
    </html>
    <?php include("../footer.php"); ?>