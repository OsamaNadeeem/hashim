<?php 
include("../header.php");
?>
<!doctype html>
    <html lang="en">
    <head>
      <meta charset="UTF-8">
      <title>Customers</title>
    </head>
    <body style="background-color:#CCC;">
    <h2 align="center" class="input-group form-signin-heading" style="margin-left:100px;">View Customers</h2> 
      <?php
      

      //execute the SQL query and return records
	  $agentname = $login_session;
	  $sql = "SELECT * FROM customers";
      $result = mysqli_query($db,$sql) or die("Error: ".mysqli_error($db));
      ?>
      <div>
      <table align="center" style="width:100%;">
      <thead>
        <tr>
          <th>First Name</th>
          <th>Last Name</th>
          <th>City</th>
          <th>Country</th>
          <th>Mobile Number</th>
          <th>Alternate Mobile Number</th>
          <th>Email</th>
                  <th>Agent Name</th>
		  <th>Active</th> 
          <th colspan="2">Action</th>                                       
        </tr>
      </thead>
      <tbody>
        <?php
          while( $row = mysqli_fetch_assoc($result) ){
            echo
            "<tr>
             
              <td>{$row['firstname']}</td>
              <td>{$row['lastname']}</td>
              <td>{$row['city']}</td>
			  <td>{$row['country']}</td>
			  <td>{$row['mobnumber1']}</td>
			  <td>{$row['mobnumber2']}</td>
			  <td>{$row['email']}</td>
			  <td>{$row['agentname']}</td>
			  <td>{$row['active']}</td>
            "?>
         <td><a id="action" href="update.php?id=<?php echo $row['id']; ?>&u=2">Update</a></td>
        <td><a id="action" href="deactivate.php?id=<?php echo $row['id']; ?>&f=6" onclick="return confirm('Are you sure?')">Delete</a></td>
       
       
        </tr>
 <?php " " ."\n            ";
          }
  ?>
      </tbody>
    </table>
    </div>
    <div id="content">
    <div class="input-group">
    <a href="view-transaction.php">View Sent Transactions</a>
    <a href="../admin/index.php">Back</a>
    </div>
    </div>
    </body>
    </html>
    <?php include("../footer.php"); ?>