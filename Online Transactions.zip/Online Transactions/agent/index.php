<html>
   
   <head>
      <title>Agent Page</title>
      <link href="../style/style.css" rel="stylesheet" type="text/css">
   </head>   
<body bgcolor = "#FFFFFF">
<?php
   include('../header.php');
?>
<div id="content">
   <a href="../agent/send-money.php">Send Money</a>
   <a href="../agent/receive-money.php">Receive Money</a>
   <a href="../agent/view-transaction.php">View Sent Transactions</a>
   <a href="../agent/view-received-transaction.php">View Received Transactions</a>
   <a href="../agent/password-change.php">Change Password</a>
   <a href="../logout.php">Log Out</a>
  </div>
<?php
   include('../footer.php');
?>
</body>
</html>