<?php
	include('../header.php');
?>
       
<html>
<head>
<title>Customer Details</title>
<link href="../style/style.css" rel="stylesheet" type="text/css" />
</head>
<body style="background-color:#CCC !important">
<h2 align="center" class="input-group form-signin-heading" style="margin-left:100px;">Customer Details</h2>
<div class="container">

		
        
        <select id="existingcust" name="to_user" class="form-control" onChange="location = this.options[this.selectedIndex].value;" required>
            <option value="pick" selected disabled>Select Customer</option>
            <?php
            $sql = mysqli_query($db, "SELECT * From customers");
            $row = mysqli_num_rows($sql);
            while ($row = mysqli_fetch_array($sql)){
            echo "<option value='exist_receive.php?id=". $row['id'] ."'>" .$row['firstname'] ." ". $row['lastname']."</option>" ;
            }
            ?>
        </select>
                <a href="index.php">Back</a>
              </form>
        </div>

   </body>
</html> 