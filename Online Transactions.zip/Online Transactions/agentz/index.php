<html>
   
   <head>
      <title>Agent Tz Page</title>
      <link href="../style/style.css" rel="stylesheet" type="text/css">
   </head>   
<body bgcolor = "#FFFFFF">
<?php
   include('../header.php');
?>
<div id="content">
   <a href="../agentz/send-money.php">Send Money</a>
   <a href="../agentz/view-transaction.php">View Transactions</a>
   <a href="../agentz/view-received-transaction.php">View Received Transactions</a>
   <a href="../agentz/password-change.php">Change Password</a>
   <a href="../logout.php">Log Out</a>
  </div>
<?php
   include('../footer.php');
?>
</body>
</html>