<?php
	include('../header.php');
	$id=$_GET['id'];
	error_reporting(E_ALL);
?>
       
<html>
<head>
<title>Customer Details</title>
<link href="../style/style.css" rel="stylesheet" type="text/css" />
</head>
<body style="background-color:#CCC !important">
<h2 align="center" class="input-group form-signin-heading" style="margin-left:100px;">Customer Details</h2> 
      <?php
      //execute the SQL query and return records
	  $agentname = $login_session;
	  $sql = "SELECT * FROM customers WHERE id='$id'";
      $result = mysqli_query($db,$sql) or die("Error: ".mysqli_error($db));
	  $cust = mysqli_fetch_assoc($result);
	  $firstname = $cust['firstname'];
	  $lastname = $cust['lastname'];
	  $city = $cust['city'];
	  $country = $cust['country'];
	  $mobnumber1 = $cust['mobnumber1'];
	  ?>
      <div>
      <table align="center" style="width:100%;">
      <thead>
        <tr>
          <th>ID</th>
          <th>First Name</th>
          <th>Last Name</th>
          <th>City</th>
          <th>Country</th>
          <th>Mobile Number</th>
          <th>Alternative Mobile Number</th>
          <th>Email</th>
          <th>Bank Details</th>
          <th>Agent</th>                                      
        </tr>
      </thead>
      <tbody>
        <tr>
              <td><?php echo $cust['id']; ?></td>
              <td><?php echo $cust['firstname']; ?></td>
              <td><?php echo $cust['lastname']; ?></td>
              <td><?php echo $cust['city']; ?></td>
              <td><?php echo $cust['country']; ?></td>
              <td><?php echo $cust['mobnumber1']; ?></td> 
			  <td><?php echo $cust['mobnumber2']; ?></td>
			  <td><?php echo $cust['email']; ?></td>
			  <td><?php echo $cust['bankdetails']; ?></td>
			  <td><?php echo $agentname; ?></td>
		</tr>
      </tbody>
    </table>
    </div>
    <div id="content">
    <div class="input-group">
    <?php echo '<a href="receive.php?firstname='.$firstname.'&lastname='. $lastname .'&city='. $city .'&country='. $country .'&mobnumber1='. $mobnumber1.'">Next</a>';
	?>
    <a href="../dataentry/index.php">Back</a>
    </div>
    </div>
</body>
</html>