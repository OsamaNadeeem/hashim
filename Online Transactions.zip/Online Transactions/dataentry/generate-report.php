<?php
include("../header.php");
?>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <title>Reports</title>
    </head>
    <body style="background-color:#CCC;">
    <h2 align="center" class="input-group form-signin-heading" style="margin-left:100px;">Generate Reports</h2>
    <div id="content">
        <a href="report-transactions.php">All Transactions</a>
        <a href="report-agent.php">Individual Agent</a>
        <a href="../dataentry/index.php">Back</a>
    </div>
    </body>
    </html>
<?php include("../footer.php"); ?>