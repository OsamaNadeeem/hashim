<?php
   include_once("../include/config.php");
   $q = intval($_GET['q']);
   $sql="SELECT * FROM customers WHERE id = '".$q."'";
   $result = mysqli_query($db,$sql);

   while($row = mysqli_fetch_array($result)) {
      $mobno=$row['mobnumber1']; 
   }
   $myObj->mobnumber=$mobno;
   $myJSON = json_encode($myObj);
   echo $myJSON;
?> 