<html>
   
   <head>
      <title>Dataentry Page</title>
      <link href="../style/style.css" rel="stylesheet" type="text/css">
   </head>   
<body bgcolor = "#FFFFFF">
<?php
   include('../header.php');
?>
<div id="content">
    <a href="register-customer.php">Create Customer</a>
   <a href="send-money.php">Send Money</a>
   <a href="receive-money.php">Receive Money</a>
   <a href="view-transaction.php">View Sent Transactions</a>
    <a href="view-received-transaction.php">View Received Transactions</a>
    <a href="generate-report.php">Generate Reports</a>
   <a href="password-change.php">Change Password</a>
   <a href="../logout.php">Log Out</a>
  </div>
</body>
</html>