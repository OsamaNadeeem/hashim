<?php
include('../header.php');
$id=$_GET['id'];
error_reporting(0);
$totalamount="";
$totalrate="";
?>
<?php


//execute the SQL query and return records
$agentname = $id;
$sql = "SELECT *,FORMAT(amount,3) as amount FROM receivedtransaction WHERE receiveragent = '$agentname'";


$result = mysqli_query($db,$sql) or die("Error: ".mysqli_error($db));
?>
<h3 align="center">Received Transactions</h3>
    <table align="center" style="width:100%;">
        <div>

            <thead  >
            <tr>
                <th>ID</th>
                <th>Date</th>
                <th>Sender Name</th>
                <th>Sender Mobile Number</th>
                <th>Sender Location</th>
                <th>Sender Agent</th>
                <th>Receiver Agent</th>
                <th>Amount in AED</th>
                <th>Amount Received</th>
                <th>Mode of Payment</th>
                <th>Payment Status</th>

            </tr>
            </thead>
            <tbody>
            <?php
            while( $row = mysqli_fetch_assoc($result) ){
                echo
                "<tr>
              <td>{$row['id']}</td>
              <td>{$row['sdate']}</td>
              <td>{$row['sendername']}</td>
              <td>{$row['sendermobnumber']}</td>
              <td>{$row['senderloc']}</td>
              <td>{$row['senderagent']}</td>
              <td>{$row['receiveragent']}</td> 
                          <td>{$row['amountsent']}</td>  
			
			  <td>{$row['amount']}</td>			  
			  <td>{$row['mode']}</td>
			  <td>{$row['paymentstatus']}</td>
             "?>
                 </tr> <?php " " ."\n            ";
                $totalamount = $totalamount + 0+str_replace(",","",$row['amount']);
                $totalrate = $totalrate + 0+str_replace(",","",$row['rate']);
            }
            ?>
            </tbody>
            <tfoot>
            <tr>
                <td colspan="7">Total</td>
                <td><?php echo $totalrate;?></td>

                <td><?php echo $totalamount;?></td>
                <td colspan="3">-</td>
            </tr>
            </tfoot>
    </table>
    </div>
    <h3 align="center">Sent Transactions</h3>
<?php
$totalamount="";
$totalrate="";
$totalamounttzs="";
$totalbuyingrate="";
$totalbuyingmainagent="";
$totalsubbuyingrate="";
$totaltotalearn="";
$totalagentservices="";
$totalsubagentservices="";
$totalservicesfordataentry="";
?>
<?php


//execute the SQL query and return records
$agentname = $id;
$sql = "SELECT *,FORMAT(amounttsz,3) as amounttsz1 FROM transaction WHERE agentname='$id'";
echo $id;
$result = mysqli_query($db,$sql) or die("Error: ".mysqli_error($db));
?>
    <div>
        <table align="center" style="width:100%;">
            <thead>
            <tr>
                <th>ID</th>
                <th>Date</th>
                <th>Sender Name</th>
                <th>Agent Type </th>
                <th>Amount</th>
                <th>Agent Name</th>

                <th>Location</th>

                <th>Receiver Name</th>
                <th>Receiver Mobile Number</th>
                <th>Receiver Agent</th>
                <th>Receiver Location</th>

                <th>Mode of Payment</th>
                <th>Rate</th>
                <th>Amount in TZS</th>
                <th>Payment Status</th>
                <th>Agent Services </th>

            </tr>
            </thead>
            <tbody>
            <?php
            while( $row = mysqli_fetch_assoc($result) ){
                echo
                "<tr>
              <td>{$row['id']}</td>
              <td>{$row['sdate']}</td>
              <td>{$row['sendername']}</td>
              <td>{$row['agenttype']}</td> 
              <td>{$row['amount']}</td>
              <td>{$row['agentname']}</td>
              <td>{$row['location']}</td>
             
              <td>{$row['receivername']}</td> 
			  <td>{$row['receivermobnumber']}</td>
			  <td>{$row['receiveragent']}</td>
			  <td>{$row['receiverlocation']}</td>
			  <td>{$row['mode']}</td>
			  <td>{$row['rate']}</td>
			  <td>{$row['amounttsz1']   }</td>
			  <td>{$row['paymentstatus']}</td>
			   <td>{$row['agentservices']}</td>
			              "?>

                </tr> <?php " " ."\n            ";
                $totalamount=((int)$totalamount)+0+str_replace(",","",$row['amount']);
                $totalrate=((int)$totalrate)+$row['rate'];
                $totalamounttzs=((int)$totalamounttzs)+0+str_replace(",","",$row['amounttsz']);
                $totalbuyingrate=((int)$totalbuyingrate)+$row['buyingrate'];
                $totalbuyingmainagent=((int)$totalbuyingmainagent)+$row['buyingmainagent'];
                $totalsubbuyingrate=((int)$totalsubbuyingrate)+$row['subbuyingrate'];
                $totaltotalearn=((int)$totaltotalearn)+$row['totalearn'];
                $totalagentservices=((int)$totalagentservices)+0+str_replace(",","",$row['agentservices']);
                $totalsubagentservices=((int)$totalsubagentservices)+$row['subagentservices'];
                $totalservicesfordataentry=((int)$totalservicesfordataentry)+$row['servicesfordataentry'];
            }
            ?>
            </tbody>
            <tfoot>
            <tr>
                <td colspan="12">Total</td>
                <td colspan="1">-</td>

                <td><b> <?php echo $totalamounttzs;?></b> </td>
                <td colspan="1">-</td>
                <td><b> <?php echo $totalagentservices;?></b> </td>
            </tr>
            </tfoot>
        </table>
    </div>
    <div id="content">

            <a href="generate-report.php">Back</a>

    </div>
    </body>
    </html>
<?php include("../footer.php"); ?>