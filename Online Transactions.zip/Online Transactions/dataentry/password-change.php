<?php
	include('../header.php');
?>
<html>
<head>
<title>Change Password</title>
<script>
function validatePassword() {
var currentPassword,newPassword,confirmPassword,output = true;

currentPassword = document.frmChange.currentPassword;
newPassword = document.frmChange.newPassword;
confirmPassword = document.frmChange.confirmPassword;

if(!currentPassword.value) {
currentPassword.focus();
document.getElementById("currentPassword").innerHTML = "required";
output = false;
}
else if(!newPassword.value) {
newPassword.focus();
document.getElementById("newPassword").innerHTML = "required";
output = false;
}
else if(!confirmPassword.value) {
confirmPassword.focus();
document.getElementById("confirmPassword").innerHTML = "required";
output = false;
}
if(newPassword.value != confirmPassword.value) {
newPassword.value="";
confirmPassword.value="";
newPassword.focus();
document.getElementById("confirmPassword").innerHTML = "not same";
output = false;
} 	
return output;
}
</script>
<link rel="stylesheet" type="text/css" href="styles.css" />
</head>
<body style="background-color:#CCC;">
    <h2 align="center" class="input-group form-signin-heading" style="margin-left:100px;">Change Password</h2>
    <div class="container">
<form name="frmChange" method="post" action="" onSubmit="return validatePassword()">
<?php
$username = $login_session;
	if(count($_POST)>0) {
		
		$result = mysqli_query($db,"SELECT * from users WHERE username='$username'") or die("Error: ".mysqli_error($db));
		$row=mysqli_fetch_array($result);
		$password=$row["password"];
		
		$currentPassword = isset($_POST['currentPassword']) ? $_POST['currentPassword'] : '';
		$newPassword = isset($_POST['newPassword']) ? $_POST['newPassword'] : '';
		if($currentPassword == $password) {
			mysqli_query($db,"UPDATE users set password='$newPassword' WHERE username='$username'");
			$message = "Password Changed. Please wait while we Redirect you to Index Page.";
			header( "refresh:5; url=../dataentry/index.php" );
		} 
		else $message = "Current Password is not correct";
	}
?>

<div class="input-group">
<table align="center" >
<tr>
<td width="40%"><label>Current Password</label></td>
<td width="60%"><input type="password" name="currentPassword" class="txtField"/><span id="currentPassword"  class="required"></span></td>
</tr>
<tr>
<td><label>New Password</label></td>
<td><input type="password" name="newPassword" class="txtField"/><span id="newPassword" class="required"></span></td>
</tr>
<td><label>Confirm Password</label></td>
<td><input type="password" name="confirmPassword" class="txtField"/><span id="confirmPassword" class="required"></span></td>
</tr>
<tr>
<td colspan="2"><input type="submit" name="submit" value="Submit" ></td>
</tr>
<tr>
<td colspan="2"><a href="../dataentry/index.php">Back</a></td>
</tr>
</table>
</div>
</div>
</form>
</div>
    </body>
    </html>
    <?php include("../footer.php"); ?>