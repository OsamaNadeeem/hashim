<?php
include("../header.php");
error_reporting(0);
function randomPassword() {
    $alphabet = "abcdefghijklmnopqrstuwxyzABCDEFGHIJKLMNOPQRSTUWXYZ0123456789";
    $pass = array(); //remember to declare $pass as an array
    $alphaLength = strlen($alphabet) - 1; //put the length -1 in cache
    for ($i = 0; $i < 8; $i++) {
        $n = rand(0, $alphaLength);
        $pass[] = $alphabet[$n];
    }
    return implode($pass); //turn the array into a string
}

if(isset($_POST['submit'])) {
    // If the values are posted, insert them into the database.
    $firstname = isset($_POST['firstname']) ? $_POST['firstname'] : '';
    $middlename = isset($_POST['middlename']) ? $_POST['middlename'] : '';
    $lastname = isset($_POST['lastname']) ? $_POST['lastname'] : '';
    $city = isset($_POST['city']) ? $_POST['city'] : '';
    //$state = isset($_POST['state']) ? $_POST['state'] : '';
    $country = isset($_POST['country']) ? $_POST['country'] : '';
    $mobnumber1 = isset($_POST['mobnumber1']) ? $_POST['mobnumber1'] : '';
    $mobnumber2 = isset($_POST['mobnumber2']) ? $_POST['mobnumber2'] : 'NULL';
    $email = isset($_POST['email']) ? $_POST['email'] : 'NULL';
    $bankdetails = isset($_POST['bankdetails']) ? $_POST['bankdetails'] : 'NULL';
    $agentname = isset($_POST['agentname']) ? $_POST['agentname'] : 'NULL';


    $password = randomPassword();

    $query="SELECT * from customers where firstname='$firstname' and middlename='$middlename' and lastname='$lastname'";
    $result = mysqli_query($db, $query) or ("Error in Customers: ".mysqli_error($db));
    $num_of_rows=mysqli_num_rows($result);
    if($num_of_rows==0){    
    $query = "INSERT INTO customers (firstname,middlename, lastname, city, country, mobnumber1, mobnumber2, email, bankdetails, agentname, active) VALUES ('$firstname','$middlename','$lastname', '$city', '$country', '$mobnumber1', '$mobnumber2', '$email', '$bankdetails' ,'$agentname', default)";

    $result = mysqli_query($db, $query) or ("Error in Customers: ".mysqli_error($db));
    if($result){
    header( "refresh:5; url=index.php" );
    }
    }
    else
        echo "Already Exists";



}

?>
    <html>
    <head>
        <title>Register Agent</title>
        <link href="../style/style.css" rel="stylesheet" type="text/css" />
    </head>
    <body style="background-color:#CCC !important">
    <h2 align="center" class="input-group form-signin-heading" style="margin-left:100px;">User Details</h2>
    <div class="container">
        <form class="form-signin" method="POST">
            <?php if(isset($smsg)){ ?><div class="alert alert-success" role="alert"> <?php echo $smsg; ?> </div><?php } ?>
            <?php if(isset($fmsg)){ ?><div class="alert alert-danger" role="alert"> <?php echo $fmsg; ?> </div><?php } ?>


            <div class="input-group">

                <label align="center">User Name</label>
                <input type="text" name="firstname" placeholder="First Name" required autofocus>
                <input type="text" name="middlename" placeholder="Middle Name" required>
                <input type="text" name="lastname" placeholder="Last Name" required>
            </div>


            <div class="input-group">

                <label align="center">Location</label>
                <input type="text" name="city" class="form-control" placeholder="City" required>
                <input type="text" name="country" class="form-control" placeholder="Country" required>
            </div>
            <div class="input-group">
                <h5 align="center" class="form-signin-heading"><b>Mobile Number</b></h5>
                <input type="text" name="mobnumber1" class="form-control" placeholder="Mobile Number" required>
            </div>
            <div class="input-group">
                <label align="center">Alternate Mobile Number</label>
                <input type="text" name="mobnumber2" class="form-control" placeholder="Alternate Mobile Number">
            </div>
            <div class="input-group">
                <label for="inputEmail" align="center">Email address</label>
                <input type="email" name="email" id="inputEmail" class="form-control" placeholder="Email address">
            </div>

            <div class="input-group">
                <label align="center">Bank Details</label>
                <input type="text" name="bankdetails" class="form-control" placeholder="Bank Details" required>
                <label align="center">Agent Name</label>
                <input type="text" name="agentname" class="form-control" placeholder="Agent Name" required>
            </div>

            <button type="submit" name="submit" >Submit</button>
            <a href="../dataentry/index.php" style="text-align:center">Back</a>
        </form>
    </div>

    </body>
    </html>
<?php include("../footer.php"); ?>