<?php
include("../header.php");
?>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <title>Reports</title>
    </head>
    <body style="background-color:#CCC;">
    <h2 align="center" class="input-group form-signin-heading" style="margin-left:100px;">Report for an Agent</h2>

    <select id="existingcust" name="to_user" class="form-control" onChange="location = this.options[this.selectedIndex].value;" required>
        <option value="pick" selected disabled>Select Customer</option>
        <?php
        $sql = mysqli_query($db, "SELECT * From agents");
        $row = mysqli_num_rows($sql);
        while ($row = mysqli_fetch_array($sql)){
            echo "<option value='individual-agent.php?id=". $row['id'] ."'>" .$row['firstname'] ." ". $row['lastname']."</option>" ;
        }
        ?>
    </select>

    <div id="content">
        <a href="../dataentry/generate-report.php">Back</a>
    </div>

    </body>

    </html>
<?php include("../footer.php"); ?>