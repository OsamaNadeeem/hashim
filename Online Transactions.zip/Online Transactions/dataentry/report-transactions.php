<?php
include("../header.php");
error_reporting(0);
$totalamount="";
$totalrate="";
?>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <title>Reports</title>
    </head>
    <body style="background-color:#CCC;">
    <h2 align="center" class="input-group form-signin-heading" style="margin-left:100px;">Report for all Transactions</h2>
    <?php


    //execute the SQL query and return records
    $agentname = $login_session;
    $sql = "SELECT * FROM receivedtransaction";
    $result = mysqli_query($db,$sql) or die("Error: ".mysqli_error($db));
    ?>
    <div>
        <h3 align="center">Received Transactions</h3>
        <table align="center">
            <thead>
            <tr>
                <th>ID</th>
                <th>Date </th>
                <th>Sender Name</th>
                <th>Sender Mobile Number</th>
                <th>Sender Location</th>
                <th>Sender Agent</th>
                <th>Receiver Agent</th>
                <th>Amount Sent</th>
                <th>Amount Received</th>
                <th>Mode of Payment</th>
                <th>Payment Status</th>
            </tr>
            </thead>
            <tbody>
            <?php
            while( $row = mysqli_fetch_assoc($result) ){
                echo
                "<tr>
              <td>{$row['id']}</td>
                <td>{$row['sdate']}</td>
              <td>{$row['sendername']}</td>
              <td>{$row['sendermobnumber']}</td>
              <td>{$row['senderloc']}</td>
              <td>{$row['senderagent']}</td>
              <td>{$row['receiveragent']}</td> 
               <td>{$row['amountsent']}</td> 
			  <td>{$row['amount']}</td>			  
			  <td>{$row['mode']}</td>
			  <td>{$row['paymentstatus']}</td>
             "?>
                </tr> <?php " " ."\n            ";
                $totalamount = $totalamount + $row['amount'];
                $totalrate = $totalrate + $row['rate'];
            }
            ?>
            </tbody>
            <tfoot>
            <tr>
                <td colspan="6">Total</td>
                <td><?php echo $totalrate;?></td>
                <td><?php echo $totalamountsent;?></td>
                <td><?php echo $totalamount;?></td>
                <td colspan="3">-</td>
            </tr>
            </tfoot>
        </table>
    </div>
    <?php


    //execute the SQL query and return records
    $agentname = $login_session;
    $sql = "SELECT AB.* ,FORMAT(AB.amounttsz,3) as amounttsz,CONCAT_WS(' ', AJ.firstname, AJ.lastname) AS AGENT_NAME,CONCAT_WS(' ', CU.firstname, CU.lastname) AS RECEVER_NAME,CONCAT_WS(' ', BJ.firstname, BJ.lastname) AS RECEVER_AJENT_NAME FROM transaction AB Left Join agents AJ on AJ.id = AB.agentname LEFT JOIN customers CU on CU.id = AB.receivername left join agents BJ on BJ.id = AB.receiveragent";
    $result = mysqli_query($db,$sql) or die("Error: ".mysqli_error($db));
    ?>
    <div>
        <h3 align="center" ><b>Sent Transactions</b></h3>
        <table align="center" style="width:150%;">
            <thead>
            <tr>
                <th>ID</th>
                <th>Sender Name</th>
                <th>Agent Name</th>
                <th>Data entered by</th>
                <th>Agent Type </th>
                <th>Location</th>
                <th>Receiver Name</th>
                <th>Receiver Mobile Number</th>
                <th>Receiver Agent</th>
                <th>Receiver Location</th>
                <th>Mode of Payment</th>
                <th>Amount in AED</th>
                <th>Rate</th>
                <th>Amount in TZS</th>


                <th>Agent Services</th>

                <th>Payment Status</th>

            </tr>
            </thead>
            <tbody>
            <?php
            while( $row = mysqli_fetch_assoc($result) ){
                echo
                "<tr>
              <td>{$row['id']}</td>
              <td>{$row['sendername']}</td>
              <td>{$row['AGENT_NAME']}</td>
              <td>{$row['DataEnterny']}</td>
              <td>{$row['agenttype']}</td>
              <td>{$row['location']}</td>
              <td>{$row['RECEVER_NAME']}</td> 
			  <td>{$row['receivermobnumber']}</td>
			  <td>{$row['RECEVER_AJENT_NAME']}</td>
			  <td>{$row['receiverlocation']}</td>
			  <td>{$row['mode']}</td>
			   <td>{$row['amount']}</td>
			  <td>{$row['rate']}</td>
			  <td>{$row['amounttsz']}</td>
					
			
			  <td>{$row['agentservices']}</td>
			
			
			  <td>{$row['paymentstatus']}</td>
			              "?>

                </tr> <?php " " ."\n            ";
                $totalamount=$totalamount+0+str_replace(",","",$row['amount']);
                $totalamounttzs=$totalamounttzs+0+str_replace(",","",$row['amounttsz']);
                $totalbuyingrate=$totalbuyingrate+$row['buyingrate'];
                $totalbuyingmainagent=$totalbuyingmainagent+$row['buyingmainagent'];
                $totalsubbuyingrate=$totalsubbuyingrate+$row['subbuyingrate'];
                $totaltotalearn=$totaltotalearn+$row['totalearn'];
                $totalagentservices=$totalagentservices+0+str_replace(",","",$row['agentservices']);
                $totalsubagentservices=$totalsubagentservices+$row['subagentservices'];
                $totalservicesfordataentry=$totalservicesfordataentry+$row['servicesfordataentry'];
            }
            ?>
            </tbody>
            <tfoot>
            <tr>
                <td colspan="2">Total</td>
                <td colspan="9">-</td>
                <td><?php echo $totalamount;?></td>
                <td colspan="1">-</td>
                <td><?php echo $totalamounttzs;?></td>
                <td><?php echo $totalagentservices;?></td>

            </tr>
            </tfoot>
        </table>
    </div>
    <div id="content">

        <a href="../dataentry/generate-report.php">Back</a>
    </div>
    </body>
    </html>
<?php include("../footer.php"); ?>