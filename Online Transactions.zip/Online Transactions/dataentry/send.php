<?php
	include('../header.php');
   
   error_reporting(0);

	/*function convertCurrency( $from, $to,$amount){
		$data = file_get_contents("https://finance.google.com/finance/converter?a=$amount&from=$from&to=$to");
		preg_match("/<span class=bld>(.*)<\/span>/",$data, $converted);
		$converted = preg_replace("/[^0-9.]/", "", $converted[1]);
		return number_format(round($converted, 3),2);
	}
           
					// change amount according to your needs
					$amount =1;
					// change From Currency according to your needs
					$from_Curr ="AED";
					// change To Currency according to your needs
					$to_Curr ="TZS";
					$rate=convertCurrency($from_Curr, $to_Curr, $amount);
					// Print outout
				*/
				
					if(isset($_POST['submit'])) {
						
		
	 	$name = $_GET['firstname'] . ' ' . $_GET['lastname'];
	    $senderlocation = $_GET ['city'] .', ' . $_GET ['country'];
		$sendermobnumber = $_GET ['mobnumber1'];
		  	
		// If the values are posted, insert them into the database.
		$sendername = $name;
		$amount = isset($_POST['amount']) ? $_POST['amount'] : '';
		$agentname =isset($_POST['agentname']) ? $_POST['agentname'] : '';

 $ses_sql2 = mysqli_query($db,"SELECT agenttype,CONCAT_WS(' ', firstname, lastname) AS RECEVER_NAME_A FROM `agents` WHERE id = '$agentname'");
   
   $row2 = mysqli_fetch_array($ses_sql2,MYSQLI_ASSOC);
$agenttype = $row2['agenttype'];
$msgname = $row2['RECEVER_NAME_A'];

$location = isset($_POST['location']) ? $_POST['location'] : '';

		$sdate = isset($_POST['sdate']) ? $_POST['sdate'] : '';
		$receivername = isset($_POST['receivername']) ? $_POST['receivername'] : '';
		$receivermobnumber = isset($_POST['receivermobnumber']) ? $_POST['receivermobnumber'] : '';		
		$receiveragent = isset($_POST['receiveragent']) ? $_POST['receiveragent'] : '';
		//echo "Default value: ".$_POST['receiverlocation'];
		if($_POST['receiverlocation']==''){
        echo "Got here";
        $receiverlocation = isset($_POST['locationselector']) ? $_POST['locationselector'] : '';
		}
		else{
			echo "new location";
		$receiverlocation = isset($_POST['receiverlocation']) ? $_POST['receiverlocation'] : '';
		$sql="INSERT into locations(location) values('$receiverlocation')";
        $result=mysqli_query($db,$sql) or die("Error in location: ".mysqli_error($db));
		}
		$mode = isset($_POST['mode']) ? $_POST['mode'] : '';
		$rate = isset($_POST['rate']) ? $_POST['rate'] : '';
		
		// Culculations
		$amounttsz = $amount * $rate;
		$buyingrate =590;
		$buyingmainagent = $buyingrate * $amount;
		
		$subbuyingrate = 580;
				
		$totalearn = $buyingmainagent - $amounttsz;
		
		
		$agentservices = $totalearn/3;
		$subagentservices = $totalearn/3;
		$servicesfordataentry = $totalearn/3;
		
		$paymentstatus = isset($_POST['paymentstatus']) ? $_POST['paymentstatus'] : '';
 
		$query = "INSERT INTO transaction (sendername, amount, agentname, agenttype, location, sdate, receivername, receivermobnumber, receiveragent, receiverlocation,  mode, rate, buyingrate, buyingmainagent, subbuyingrate, totalearn, agentservices, subagentservices, servicesfordataentry, amounttsz, paymentstatus,DataEnterny) VALUES ('$sendername', '$amount', '$agentname', '$agenttype','$location', '$sdate','$receivername', '$receivermobnumber', '$receiveragent', '$receiverlocation', '$mode', '$rate','$buyingrate', '$buyingmainagent', '$subbuyingrate', '$totalearn', '$agentservices', '$subagentservices', '$servicesfordataentry', '$amounttsz', '$paymentstatus','$login_session') ";
		$result = mysqli_query($db, $query) or die("Error in transaction: ".mysqli_error($db));
		$query2 = mysqli_query($db, "INSERT INTO receivedtransaction (sendername, sendermobnumber, senderloc, sdate, senderagent, agenttype, receiveragent, rate, amount, mode, paymentstatus) VALUES ('$sendername', '$sendermobnumber', '$location', '$sdate', '$agentname', 'agenttype', '$receiveragent', '$rate', '$amounttsz', '$mode', '$paymentstatus')") or die("Error in received transaction: ".mysqli_error($db));
		
		$email = mysqli_query($db, "SELECT email FROM agents WHERE username='$receiveragent'")or die("Error: ".mysqli_error($db));
		
		
		if($result === TRUE){
			$smsg = "Money Sent Successfully! Amount in TZS : '.$amounttsz'";
			$smsg = $smsg . "Money Received from '$msgname' by '$sendername'. Please wait while we Redirect you to Index Page.";
			$toEmail = $email;
			$subject = "Money Received from '$agentname' by '$sendername'";
			$content = "User '$receivername' has Received Money sent from '$location' by '$sendername'. Please MoneyTran for More Details.";
			$mailHeaders = "From: Agent\r\n";
			if(mail($toEmail, $subject, $content, $mailHeaders)) {
				$smsg = $smsg ."Mail Sent Successfully!";
			}
			header( "refresh:5; url=index.php" );
		}else{
			$fmsg ="Money Sending Failed. Try Again!";
		}
   }
   

?>      
<html>
<head>
<title>Receiver Details</title>
<link href="../style/style.css" rel="stylesheet" type="text/css" />
 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script type="text/javascript">
function updateInput(ish){
    document.getElementById("buyingmain").value = ish * <?php echo $rate + 25 ?>;
	document.getElementById("amountrec").value = ish * <?php echo $rate+0 ?>;
	document.getElementById("totalearn").value = (ish * <?php echo $rate +25 ?>) - (ish * <?php echo $rate+0 ?>);
	document.getElementById("agentser").value = ((ish * <?php echo $rate +25 ?>) - (ish * <?php echo $rate+0 ?>))/3;
	document.getElementById("subagentser").value = ((ish * <?php echo $rate +25 ?>) - (ish * <?php echo $rate+0 ?>))/3;
	document.getElementById("dataentry").value = ((ish * <?php echo $rate +25 ?>) - (ish * <?php echo $rate+0 ?>))/3;
}
</script>

<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.3.1/css/all.css" integrity="sha384-mzrmE5qonljUremFsqc01SB46JvROS7bZs3IO2EmfFsd15uHvIt+Y8vEf7N7fWAU" crossorigin="anonymous">
</head>
<body style="background-color:#CCC !important">
	
<h2 align="center" class="input-group form-signin-heading" style="margin-left:100px;">Receiver Details</h2>
<div class="container" style"padding:0px; margin:0px;">

			  <form class="form-signin" method="POST" >
			  
	   <?php if(isset($smsg)){ ?><div class="alert alert-success" role="alert"> <?php echo $smsg; ?> </div><?php } ?>
	   <?php if(isset($fmsg)){ ?><div class="alert alert-danger" role="alert"> <?php echo $fmsg; ?> </div><?php } ?>
	<table border="1" style="width:860px;">
 <tr> 
    <td>
	          <div class="input-group">  
	           
			  <label align="center">Sender Name</label>
			  <input type="text" name="sendername" class="form-control" value="<?php echo $name = $_GET['firstname'] . ' ' . $_GET['lastname']; ?>" disabled>
			  </div>
            
             
             <div class="input-group">
              <label align="center">Agent Name</label>
			  <select style="width:350px;" id="existingcust" name="agentname" class="form-control" onChange="location = this.options[this.selectedIndex].value;" required >
           <option value="pick" selected disabled>Select Agent</option>
            <?php
            $sql = mysqli_query($db, "SELECT * From agents");
            $row = mysqli_num_rows($sql);
            while ($row = mysqli_fetch_array($sql)){
            echo "<option value='". $row['id'] ."'>" .$row['firstname'] ." ". $row['lastname']."</option>" ;
            }
            ?>
        </select>
        
			  </div>
	      <div class="input-group">
	     <label align="center">User Type</label>
	     <input type="text" name="agenttype" class="form-control" value="<?php echo $login_session_type; ?>" disabled>
			  </div>
             <div class="input-group">
              <label align="center">Location</label>
			  <input type="text" name="location" class="form-control" value="<?php echo $senderlocation = $_GET ['city'] .', ' . $_GET ['country']; ?>" readonly>
				</div>
	
	     	    <div class="input-group" >
				<label align="center">Date</label>
				<input type="date" name="sdate" class="form-control" style="width: 350px" placeholder="Date" required>
				</div>
				
				  <div class="input-group">
              <label class="amount" align="center">Amount in AED</label>
			  <input type="text" name="amount" id="amount" class="form-control" placeholder="Amount" onchange="updateInput(this.value)" required>
			  </div>

                <div class="input-group">
				<label align="center">Receiver Name</label>
				
              <script type="text/javascript">
	function filldetails(str) {
  if (window.XMLHttpRequest) {
    // code for IE7+, Firefox, Chrome, Opera, Safari
    xmlhttp=new XMLHttpRequest();
  } else { // code for IE6, IE5
    xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
  xmlhttp.onreadystatechange=function() {
    if (this.readyState==4 && this.status==200) {
    	 var myObj = JSON.stringify(this.responseText);
    	 alert(myObj.mobnumber);
      document.getElementById("receivermobnumber").value=myObj.mobnumber;	
    }
  }
  xmlhttp.open("GET","getuser.php?q="+str,true);
  xmlhttp.send();
}
</script>
			 <select style="width:350px;" id="existingcust" name="receivername" class="form-control" onchange="location = this.options[this.selectedIndex].value; filldetails(this.value);" required >
            <option value="pick" selected disabled>Select Agent</option>
            <?php
            $sql5 = mysqli_query($db, "SELECT id,firstname,lastname FROM customers");
            $row5 = mysqli_num_rows($sql5);
            while ($row5 = mysqli_fetch_array($sql5)){
            echo "<option value='". $row5['id'] ."'>" .$row5['firstname'] ." ". $row5['lastname']."</option>" ;
            }
            ?>
        </select>
				</div>
</td>
<td>				
				
                <div class="input-group">
                <label align="center">Receiver Mobile Number</label>
				<input type="text" id="receivermobnumber" name="receivermobnumber" class="form-control" placeholder="Receiver Mobile Number">
				</div>


                <div class="input-group">
                <label align="center">Receiver Location</label>
                <input type="hidden" id="receiverlocation" name="receiverlocation" class="form-control" placeholder="Reciever Location">
				<select style="width:350px;" id="locationselector" name="locationselector" class="form-control" onChange="location = this.options[this.selectedIndex].value;" required >
		            <option value="pick" selected disabled>Select Location</option>
		            <?php
		            $sql = mysqli_query($db, "SELECT * From locations");
		            $row = mysqli_num_rows($sql);
		            while ($row = mysqli_fetch_array($sql)){
		            echo "<option value='". $row['id'] ."'>".$row['location']."</option>" ;
		            }
		            ?>
       			 </select>
       			 <a id="addnew" onclick="addnew()"><i>Add other Location</i></a>

       			 <script type="text/javascript">
       			 	function addnew(){
       			 		document.getElementById('receiverlocation').type="text";
       			 		document.getElementById('locationselector').style.display="none";
       			 		document.getElementById('addnew').style.display="none";
       			 	}
       			 </script>
       			 
				</div>
                <div class="input-group">
                
                
                <label align="center">Receiver Agent Name</label>
			 <select style="width:350px;" id="existingcust" name="receiveragent" class="form-control" onChange="location = this.options[this.selectedIndex].value;" required >
            <option value="pick" selected disabled>Select Agent</option>
            <?php
            $sql = mysqli_query($db, "SELECT * From agents");
            $row = mysqli_num_rows($sql);
            while ($row = mysqli_fetch_array($sql)){
            echo "<option value='". $row['id'] ."'>" .$row['firstname'] ." ". $row['lastname']."</option>" ;
            }
            ?>
        </select>
        
        
			  	</div>
                <div class="input-group">
                <label align="center">Mode of Payment</label>
				<input type="text" name="mode" class="form-control" placeholder="Mode of Payment">
				</div>
                <div class="input-group">
                <label align="center">Rate</label>
				<input type="text" name="rate" class="form-control" placeholder="Rate">
				</div>
                <div class="input-group">
                <label align="center">Amount to be Received</label>
				<input id="amountrec" type="text" name="amounttsz" class="form-control" placeholder="Amount" value="<?php echo $amounttsz ?>" disabled>
				</div>
                <div class="input-group">
               
                
                
                <div class="input-group">
                <label align="center">Payment Status</label>
				<select name="paymentstatus" style="width:350px" required>
                	<option value="Pending" selected disabled>Select Payment</option>
                    <option value="Paid">Paid</option>
                    <option value="Pending">Pending</option>
                </select>
				</div>
</td> 
</tr> 
   </table>
   <center> 
                <button  type="submit" name="submit">Send</button>
				<a href="../dataentry/index.php">Back</a>
			  </form>
			
		</div>
	  </center> 
   </body>
</html>