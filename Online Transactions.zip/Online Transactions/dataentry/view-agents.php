<?php 
error_reporting( E_ALL );
include("../header.php");
?>
<!doctype html>
    <html lang="en">
    <head>
      <meta charset="UTF-8">
      <title>Dataentry</title>
    <link href="../style/style.css" rel="stylesheet" type="text/css">
    </head>
    <body style="background-color:#CCC;">
    <h2 align="center" class="input-group form-signin-heading" style="margin-left:100px;">View Agents</h2> 
      <?php
      

      //execute the SQL query and return records
	  $agentname = $login_session;
	  $sql = "SELECT * FROM agents";
      $result = mysqli_query($db,$sql) or die("Error: ".mysqli_error($db));
      ?>
      <div>
      <table align="center">
      <thead>
        <tr>
          <th>ID</th>
          <th>First Name</th>
          <th>Second Name</th>
          <th>Last Name</th>
		  <th> User Name</th>
          <th>City</th>
          <th>Country</th>
          <th>Mobile Number</th>
          <th>Alternate Mobile Number</th>
          <th>Email</th>
          <th>Agent Type</th>
		  <th>Active</th> 
                              
        </tr>
      </thead>
      <tbody>
        <?php
          while( $row = mysqli_fetch_assoc($result) ){
            echo
            "<tr>
              <td>{$row['id']}</td>
              <td>{$row['firstname']}</td>
              <td>{$row['secondname']}</td>
              <td>{$row['lastname']}</td>
<td>{$row['username']}</td>
              <td>{$row['city']}</td>
              
			  <td>{$row['country']}</td>
			  <td>{$row['mobnumber1']}</td>
			  <td>{$row['mobnumber2']}</td>
			  <td>{$row['email']}</td>
			  <td>{$row['agenttype']}</td>
			  <td>{$row['active']}</td>
"?>
       
        </tr>
 <?php " " ."\n            ";
          }
  ?>
      </tbody>
    </table>
    </div>
    <div id="content">
    <div class="input-group">
    <a href="view-customers.php">View Customers</a>
    <a href="../dataentry/index.php">Back</a>
    </div>
    </div>
    </body>
    </html>
    <?php include("../footer.php"); ?>