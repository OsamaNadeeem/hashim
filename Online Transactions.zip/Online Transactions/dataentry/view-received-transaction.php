<?php 
include("../header.php");
error_reporting(0);
$totalamount="";
$totalrate="";
?>
<!doctype html>
    <html lang="en">
    <head>
      <meta charset="UTF-8">
      <title>Received Transactions</title>
    </head>
    <body style="background-color:#CCC;">
    <h2 align="center" class="input-group form-signin-heading" style="margin-left:100px;">View Received Transactions</h2>
      <?php
      

      //execute the SQL query and return records
	  $agentname = $login_session;
	  $sql = "SELECT * FROM receivedtransaction";
      $result = mysqli_query($db,$sql) or die("Error: ".mysqli_error($db));
      ?>
      <div>
      <table align="center">
      <thead>
        <tr>
          <th>ID</th>
          <th>Date </th>
          <th>Sender Name</th>
          <th>Sender Mobile Number</th>
          <th>Sender Location</th>
          <th>Sender Agent</th>
          <th>Receiver Agent</th>
            <th>Amount Sent (AED)</th>
          <th>Amount Received</th>    
          <th>Mode of Payment</th> 
          <th>Payment Status</th>
        </tr>
      </thead>
      <tbody>
        <?php
          while( $row = mysqli_fetch_assoc($result) ){
           $sql1="SELECT * from agents where id=".$row['receiveragent'];
           $result1 = mysqli_query($db,$sql1) or die("Error in agents: ".mysqli_error($db));
           $row1 = mysqli_fetch_assoc($result1);
           $firstname=$row1['firstname'];
           $middlename=$row1['middlename'];
           $lastname=$row1['lastname'];
           $abbr='';
           $abbr=$firstname[0].$middlename[0].$lastname[0];
            echo
            "<tr>
              <td>{$row['id']}</td>
                <td>{$row['sdate']}</td>
              <td>{$row['sendername']}</td>
              <td>{$row['sendermobnumber']}</td>
              <td>{$row['senderloc']}</td>
              <td>ksk</td>
              <td>{$abbr}</td> 
               <td>{$row['amountsent']}</td> 
			  <td>{$row['amount']}</td>			  
			  <td>{$row['mode']}</td>
			  <td>{$row['paymentstatus']}</td>
             "?>
        	</tr> <?php " " ."\n            ";
			$totalamount = $totalamount + $row['amount'];
			$totalrate = $totalrate + $row['rate'];
          }
  ?>
      </tbody>
      <tfoot>
            <tr>
              <td colspan="8">Total</td>
              <td><?php echo $totalamount;?></td>
              <td colspan="3">-</td>
            </tr>
  		</tfoot>
    </table>
    </div>
    <div id="content">
    <div class="input-group">
    <a href="view-transaction.php">View Sent Transactions</a>
    <a href="../dataentry/index.php">Back</a>
     </div>
    </div>
    </body>
    </html>
    <?php include("../footer.php"); ?>