<html>
<link href="style/style.css" rel="stylesheet" type="text/css">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<body>
<div id="footer">
<div class="footcont">
  <div class="column">
    <h4>Copyright © 2017. All Rights Reserved.</h4>
  </div>
</div>
</div>
</body>
</html>