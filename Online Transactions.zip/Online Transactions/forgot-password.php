<?php
   // Turn off all error reporting
   error_reporting(0);
   include("include/config.php");
   
function randomPassword() {
    $alphabet = "abcdefghijklmnopqrstuwxyzABCDEFGHIJKLMNOPQRSTUWXYZ0123456789";
    $pass = array(); //remember to declare $pass as an array
    $alphaLength = strlen($alphabet) - 1; //put the length -1 in cache
    for ($i = 0; $i < 8; $i++) {
        $n = rand(0, $alphaLength);
        $pass[] = $alphabet[$n];
    }
    return implode($pass); //turn the array into a string
}

   
   if($_SERVER["REQUEST_METHOD"] == "POST") {
      // username and password sent from form 
      
      $email = isset($_POST['email']) ? $_POST['email'] : '';
      
      $sql = "SELECT `id`,`username`,`password`,`email` FROM `users` WHERE `email`='$email'";
      $result = mysqli_query($db,$sql) or die("Error: ".mysqli_error($db));
      $row = mysqli_fetch_array($result);
	  $username = $row['username'];
	  $id = $row['id'];
	  $password = randomPassword();
	  if($result) {
		$query = "UPDATE users SET password = '$password' WHERE id = '$id'";
		$qres = mysqli_query($db,$query) or die("Error: ".mysqli_error($db));	
		if($qres === TRUE) {
			$smsg = "Password Reset Successfully! Please wait while we Redirect you to Index Page.";
			$toEmail = $_POST["email"];
			$subject = "Your Password has been Reset";
			$content = "Your Password has been Reset. Here is your <br /> Username : '$username' <br />Password : '$password' <br />MoneyTran <br />Thank You <br />With Regards <br />MoneyTran Admin";
			$mailHeaders = "From: Admin\r\n";
			if(mail($toEmail, $subject, $content, $mailHeaders)) {
				$smsg = $smsg . "Your Password has been sent your Mail!";
}
			
        }else{
            $fmsg ="Password couldnt be Changed! Please Try Again! Please wait while we Redirect you to Index Page.";
        }
		
	  header( "refresh:5; url=index.php" );

			
	  }
	  else {
		  $fmsg ="User does not exist! Please Enter the correct Email!";
	  }
	}
?>
<html>
   
   <head>
      <title>Forgot Password</title>
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <style type = "text/css">
         body {
            font-family:Arial, Helvetica, sans-serif;
            font-size:14px;
         }
         
         label {
            font-weight:bold;
            width:100px;
            font-size:14px;
         }
         
         .box {
            border:#666666 solid 1px;
         }
      </style>
      <link href="style/style.css" rel="stylesheet" type="text/css">
   </head>
   
   
   <body bgcolor = "#FFFFFF">
   
    <div id="header">
      <img alt="MoneyTran" src="images/Logo.png" class="logo" />
      <h1 id="header-title" style="display:inline-block; float:right; margin:50px;"> Welcome</h1>
	</div>
    
    
    <div id="content">
      <div class="container">
         <div class="about">
            <div class="about-author"><h1><b>Forgot Password?</b></h1></div>
				
            <div>
               <?php if(isset($smsg)){ ?><div class="alert alert-success" role="alert"> <?php echo $smsg; ?> </div><?php } ?>
               <?php if(isset($fmsg)){ ?><div class="alert alert-danger" role="alert"> <?php echo $fmsg; ?> </div><?php } ?>
               <form method = "post">
               <label>Enter your E-mail below:</label><input type = "text" name = "email" required/><br /><br />
                  <input type = "submit" value = " Submit "/><br />            
               </form>
               <a href="index.php" style="text-align:center; width:90% !important; height:30px; text-decoration:none;">Login</a>
					
            </div>
				
         </div>
			
      </div>
      </div>
      <div id="footer">
      <?php include("footer.php") ?>
      </div>
   </body>
</html>