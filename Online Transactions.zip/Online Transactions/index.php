<?php
   // Turn off all error reporting
   error_reporting(0);
   include("include/config.php");
   
   session_start();
   
   if($_SERVER["REQUEST_METHOD"] == "POST") {
      // username and password sent from form 
      
      $myusername = mysqli_real_escape_string($db,$_POST['username']);
      $mypassword = mysqli_real_escape_string($db,$_POST['password']); 
      
      $sql = "SELECT * FROM users WHERE username = '$myusername' and password = '$mypassword'";
      $result = mysqli_query($db,$sql) or die("Error: ".mysqli_error($db));
      $row = mysqli_fetch_array($result,MYSQLI_ASSOC);
      $active = $row['active'];
	  $user_type = $row['usertype'];
	        
      $count = mysqli_num_rows($result);
      
      // If result matched $myusername and $mypassword, table row must be 1 row
	  
    
     if($count == 1) {
        // session_register("myusername");
		// session_register("password");
         $_SESSION['login_user'] = $myusername;
		 if($user_type == "admin")
		 {        
          header("location: ../admin/index.php");
		 } else if($user_type == "Super Agent")
		 {
			  header("location: ../superage/index.php");
		 }else if($user_type == "dataentry")
		 {
			  header("location: ../dataentry/index.php");
		 } else {
			 header("location: ../agent/index.php");
		 }
      }else {
         $error = "Your Login Name or Password is invalid";
      }
   }
  ?>
<html>
   
   <head>
   
	<meta name="viewport" content="width=device-width, initial-scale=1.0">

      <title>Login Page</title>
      
      <style type = "text/css">
         body {
            font-family:Arial, Helvetica, sans-serif;
            font-size:14px;
         }
         
         label {
            font-weight:bold;
            width:100px;
            font-size:14px;
         }
         
         .box {
            border:#666666 solid 1px;
         }
      </style>
      <link href="style/style.css" rel="stylesheet" type="text/css">
   </head>
   
   
   <body bgcolor = "#FFFFFF">
   
    <div id="header">
      <img alt="MoneyTran" src="images/Logo.png" class="logo" />
      <h1 id="header-title" style="display:inline-block; float:right; margin:50px;"> Welcome</h1>
	</div>
    
    
    <div id="content">
      <div class="container">
         <div class="about">
            <div class="about-author"><h1><b>Login</b></h1></div>
				
            <div>
               
               <form method = "post">
                  <label>User Name</label><input type = "text" name = "username" required style="margin-left: 5px;"/><br /><br />
                  <label>Password</label><input type = "password" name = "password" class = "box" required style="margin-left: 5px;"/><br/><br />
                  
                  
                  <input type = "submit" value = " Submit " style="margin:auto;" /><br /><br />
                                  
               
               <a href="forgot-password.php" style="width:30px; height:20px; text-decoration:none; background-color:#09F; margin-left:175px;">Forgot Password</a>
          
		
		
            </div>
            
			  <div style = "font-size:11px; color:#cc0000; margin-top:10px"><?php echo $error; ?></div> 	
         </div>
			
      </div>
      </div>
      
      <div id="footer">
      <?php include("footer.php") ?>
      </div>
   </body>
</html>