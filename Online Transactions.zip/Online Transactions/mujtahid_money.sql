-- phpMyAdmin SQL Dump
-- version 4.3.8
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jun 18, 2018 at 12:46 PM
-- Server version: 5.6.32-78.1
-- PHP Version: 5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `mujtahid_money`
--

-- --------------------------------------------------------

--
-- Table structure for table `agents`
--

CREATE TABLE IF NOT EXISTS `agents` (
  `id` int(255) NOT NULL,
  `firstname` varchar(50) NOT NULL,
  `lastname` varchar(50) NOT NULL,
  `username` varchar(50) NOT NULL,
  `city` varchar(50) NOT NULL,
  `country` varchar(50) NOT NULL,
  `mobnumber1` varchar(200) NOT NULL,
  `mobnumber2` varchar(20) DEFAULT NULL,
  `email` varchar(50) NOT NULL,
  `agenttype` varchar(20) NOT NULL,
  `active` int(1) NOT NULL DEFAULT '1'
) ENGINE=MyISAM AUTO_INCREMENT=24 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `agents`
--

INSERT INTO `agents` (`id`, `firstname`, `lastname`, `username`, `city`, `country`, `mobnumber1`, `mobnumber2`, `email`, `agenttype`, `active`) VALUES
(1, 'Khamis', 'Abulani', 'kawadh@yahoo.com', 'Abu Dhabi ', 'UAE', '+971557204777', '+971557204777', 'kawadh@yahoo.com', 'Sub Agent', 1),
(15, 'Rabia Salim', 'Al Abri', 'r_alabri@hotmail.com', 'Abu Dhabi', 'UAE', '+971527204777', '+971507441318', 'r_alabri@hotmail.com', 'Super Agent', 1),
(17, 'Suleiman', 'Abdallah', 'sule.73@hotmail.com', 'Abu Dhabi', 'UAE', '+971507620657', '+971554872132', 'sule.73@hotmail.com', 'Sub Agent', 1),
(18, 'Said', 'Ali Sharif', 'aidsharif27@yahoo.com', 'Abu Dhabi', 'UAE', '+97158153587', '+971528788425', 'saidsharif27@yahoo.com', 'Sub Agent', 1),
(19, 'Karama', 'Said Karama', 'kubaya@gmail.com', 'Zanzibar', 'Tanzania', '+255777410939', '+255787879898', 'kubaya@gmail.com', 'Super Agent', 1),
(20, 'Naila', 'Salim Al Abri', 'nayla333@hotmail.com', 'Muscat', 'Oman', '+255773100944', '', 'nay@ooo.com', 'Sub Agent', 1),
(21, 'Khalid', 'Yusuf Bahasan', 'kyussph@yahoo.com', 'Dubai', 'UAE', '+971502414272', '+971569934169', 'kyussph@yahoo.com', 'Sub Agent', 1),
(22, 'Shamis', 'Mohammed', 'shamismohammed', 'Kuala Lumpur', 'Malaysia ', '+60173570891', '', 'shamissaid@gmail.com', 'Dataentry', 1),
(23, 'Mohd', 'Ali', 'mohdali', 'zanzibar', 'tanzania', '0777648769', '', 'alyafyfreal@gmail.com', 'Dataentry', 1);

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

CREATE TABLE IF NOT EXISTS `customers` (
  `id` int(255) NOT NULL,
  `customerid` varchar(20) NOT NULL,
  `firstname` varchar(50) NOT NULL,
  `lastname` varchar(50) NOT NULL,
  `city` varchar(50) NOT NULL,
  `country` varchar(50) NOT NULL,
  `mobnumber1` varchar(200) NOT NULL,
  `mobnumber2` varchar(20) DEFAULT NULL,
  `email` varchar(30) DEFAULT NULL,
  `bankdetails` varchar(255) DEFAULT NULL,
  `agentname` varchar(50) NOT NULL,
  `active` int(1) NOT NULL DEFAULT '1'
) ENGINE=MyISAM AUTO_INCREMENT=182 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customers`
--

INSERT INTO `customers` (`id`, `customerid`, `firstname`, `lastname`, `city`, `country`, `mobnumber1`, `mobnumber2`, `email`, `bankdetails`, `agentname`, `active`) VALUES
(14, '', 'Shaban', 'Rashid', 'Al Ain', 'UAE', '+971559891887', '+255777489019', '', 'Zahran Halwa Oman', 'agent', 1),
(15, '', 'Khamis', 'Maulid', 'Abu Dhabi', 'UAE', '+971507642281', '', '', 'TIP', 'agent', 1),
(16, '', 'Abdallah', 'Juma', 'Abu Dhabi', 'UAE', '+971557166088', '+917507121919', '', 'National ', 'agent', 1),
(44, '', 'Bint', 'Dahal', 'Abu Dhabi', 'UAE', '+971564840171', '', '', '', 'kawadh@yahoo.com', 1),
(43, '', 'Khamis', 'Maulid', 'Abu Dhabi', 'UAE', '+971526894346', '+971507642281', '', '', 'kawadh@yahoo.com', 1),
(20, '', 'Juma Khamis', 'Ahmada', 'Dubai', 'UAE', '+971554105951', '', '', 'Majid Khamis (Customer) - MSS', 'agent', 1),
(21, '', 'Masoud', 'Suleiman', 'Abu Dhabi', 'UAE', '+971559717478', '', '', 'Zahran Halwa', 'agent', 1),
(22, '', 'Masoud', 'Suleiman', 'Abu Dhabi', 'UAE', '+97159717478', '', '', 'Zaharan Halwa', 'agent', 1),
(23, '', 'Mohamed Abdallah', 'Al Azri', 'Abu Dhabi', 'UAE', '+971559420349', '+971507926180', '', '', 'agent', 1),
(24, '', 'Mussa Faki', 'Hamadi', 'Dubai', 'UAE', '+917507458165', '', '', '', 'agent', 1),
(25, '', 'Mohamed Maulid', 'Simai', 'Abu Dhabi', 'UAE', '+971553177924', '', '', '', 'agent', 1),
(26, '', 'Sabra', 'Abdallah', 'Abu Dhabi', 'UAE', '+917525860132', '', '', '', 'agent', 1),
(27, '', 'Humoud ', 'Al Abri', 'Muscat', 'Oman', '+96899383025', '', '', '', 'agent', 1),
(28, '', 'Anwar', 'Khamis', 'Abu Dhabi', 'UAE', '+971567273204', '', '', '', 'agent', 1),
(29, '', 'Khamis', 'Abulani', 'Abu dhabi', 'UAE', '+971557204777', '', '', '', 'kawadh@yahoo.com', 1),
(30, '', 'Ali', 'Khamis Ali', 'Dubai', 'UAE', '+971555329454', '', '', '', 'kawadh@yahoo.com', 1),
(31, '', 'Hawa', 'Baharoon', 'Abu Dhabi', 'UAE', '13350352', '', '', '', 'r_alabri@hotmail.com', 1),
(45, '', 'Salum', 'Hamadi - ZH', 'Abu Dhabi', 'UAE', '+971529779349', '', '', '', 'kawadh@yahoo.com', 1),
(46, '', 'Salma ', 'Abdallah - National', 'Abu Dhabi', 'UAE', '+971553611277', '', '', '', 'kawadh@yahoo.com', 1),
(47, '', 'Ibrahim', 'Nassor', 'ADubai', 'UAE', '+971557866785', '', '', '', 'kawadh@yahoo.com', 1),
(48, '', 'Laki', 'Bin Moosa', 'Abu Dhabi', 'UAE', '+971506133953', '', '', '', 'r_alabri@hotmail.com', 1),
(49, '', 'Fauzia', 'Rabia refence', 'Abu Dhabi', 'UAE', '+971507441318', '', '', '', 'r_alabri@hotmail.com', 1),
(50, '', 'Fatma', 'Mohamed Juma', 'Abu Dhabi', 'UAE', '+971503152363', '', '', '', 'r_alabri@hotmail.com', 1),
(51, '', 'Ahmada', 'Juma', 'Abu Dhabi', 'UAE', '9715', '', '', '', 'kawadh@yahoo.com', 1),
(56, '', 'test', 'alyafy', 'sharjah', 'uae', '+9718523665', '+25589637412', '', '', 'kawadh@yahoo.com', 1),
(57, '', 'Twaha', 'Rashid', 'Abu Dhabi', 'Tanzania', '+255683876620', '', '', '', 'dataentry', 1),
(58, '', 'Karima', 'Said', 'Muscat', 'Oman', '+968', '', '', '', 'dataentry', 1),
(59, '', 'Layla', '1', 'Muscat', 'Oman', '+968', '', '', '', 'dataentry', 1),
(60, '', 'Hanifa', 'Yusuf', 'Dubai', 'UAE', '+9715', '', '', '', 'dataentry', 1),
(61, '', 'Jaffar', 'Sharjah', 'Sharjah', 'UAE', '+971', '', '', '', 'dataentry', 1),
(62, '', 'Fauzia', 'Abu Dhabi', 'Abu Dhabi', 'UAE', '+9715', '', '', '', 'dataentry', 1),
(63, '', 'Fauzia', 'Duka la Halua', 'Abu Dhabi', 'UAE', '+9715', '+9715', '', '', 'dataentry', 1),
(64, '', 'Kassim', 'Ali Kassim', 'Zanzibar', 'Tanzania', '+255', '+255', '', '', 'dataentry', 1),
(65, '', 'Shabeera', 'Kassam', 'Unguja', 'Tanzania', '+255', '+255', '', '', 'dataentry', 1),
(66, '', 'Mohammed', 'Al Abari', 'Muscat', 'Oman', '+968923735031', '', '', '', 'dataentry', 1),
(67, '', 'Saada', 'Ali', 'Unguja', 'Tanzania', '+255778499993', '', '', '', 'dataentry', 1),
(68, '', 'Alwyia', 'Baharoon', 'Abu Dhabi', 'Abu Dhabi', '+9715', '', '', '', 'dataentry', 1),
(69, '', 'Fauzia', 'Mahmoud', 'Dar es Salaam', 'Tanzania', '+255767067971', '', '', '', 'dataentry', 1),
(70, '', 'Asha', 'Mahmoud', 'Abu Dhabi', 'UAE', '+97152130133', '', '', '', 'dataentry', 1),
(71, '', 'Mohammed', 'Al abry', 'Muscat', 'Oman', '+968', '+968', '', '', 'dataentry', 1),
(72, '', 'Rabia', 'Alabri', 'Abu Dhabi', 'UAE', '+9715', '+9715', '', '', 'dataentry', 1),
(73, '', 'Haroub', 'Hemed', 'Zanzibar', 'Tanzania', '+255', '+255', '', '', 'dataentry', 1),
(74, '', 'Pili Iddi', 'Ame', 'Unguja', 'Tanzania', '+255', '+255', '', '', 'dataentry', 1),
(75, '', 'Salum', 'Mussa', 'Bureimi', 'Oman', '+9715', '+9715', '', '', 'dataentry', 1),
(76, '', 'Amour Ali', 'Talib', 'Unguja', 'Tanzania', '+255', '+255', '', '', 'dataentry', 1),
(77, '', 'Silima', 'Rashid', 'Alain', 'UAE', '+9715', '+9715', '', '', 'dataentry', 1),
(78, '', 'Maiya', 'Khamis', 'Unguja', 'Tanzani', '+255776406461', '+255', '', '', 'dataentry', 1),
(79, '', 'Khamis ', 'Kassim', 'Unguja', 'Tanzania', '+255', '+255', '', '', 'dataentry', 1),
(80, '', 'Abas', 'Haji', 'Abu Dhabi', 'UAE', '+9715', '+9715', '', '', 'dataentry', 1),
(81, '', 'Hidaya', 'Mtumwa', 'Unguja', 'Tanzania', '+255', '+255', '', '', 'dataentry', 1),
(82, '', 'Ally', 'Sharif', 'Abu Dhabi', 'UAE', '+9715', '+9715', '', '', 'dataentry', 1),
(83, '', 'Bishara', 'Rajab', 'Unguja', 'Tanzania', '+255', '+255', '', '', 'dataentry', 1),
(84, '', 'Mohamed', 'Abdallah', 'Abu Dhabi', 'UAE', '+9715', '+9715', '', '', 'dataentry', 1),
(85, '', 'Mur ', 'Nassor', 'Unguja', 'Tanzania', '+255', '+255', '', '', 'dataentry', 1),
(86, '', 'Nassor', 'Saleem', 'Abu Dhabi', 'UAE', '+9715', '+9715', '', '', 'dataentry', 1),
(87, '', 'Rukia ', 'Iddi', 'Unguja', 'Tanzania', '+255', '+255', '', '', 'dataentry', 1),
(88, '', 'Esta', 'Simon', 'Dar', 'Tanzania', '+255717826767', '+255717826767', '', '', 'dataentry', 1),
(89, '', 'Asia', 'Kigwande', 'Dar', 'Tanzani', '+255713517139', '+255713517139', '', '', 'dataentry', 1),
(90, '', 'Suleiman', 'Omar', 'Unguja', 'Hassan Suleiman', '+25579253225', '+25579253225', '', '', 'dataentry', 1),
(91, '', 'Hassan ', 'Suleiman', 'Abu Dhabi', 'UAE', '+9715', '+9715', '', '', 'dataentry', 1),
(92, '', 'Hemed', 'Ali', 'Unguja', 'Tanzania', '+255', '+255', '', '', 'dataentry', 1),
(93, '', 'Said', 'Mahrouqi', 'Unguja', 'Tanzania', '+255', '+255', '', '', 'dataentry', 1),
(94, '', 'Seif', 'Ali', 'Abu Dhabi', 'UAE', '+9715', '+9715', '', '', 'dataentry', 1),
(95, '', 'Shamis Said', 'Mohammed', 'Kuala Lumpur', 'Malaysia', '+60173570891', '+60173570891', 'shamissaid@gmail.com', 'Shamis Said Mohammed\r\n164017-322596\r\nMalayan Banking Berhad (3813-K)\r\nMenara Maybank\r\n100 Jalan Tun Perak\r\n50050 Kuala Lumpur, Malaysia', 'dataentry', 1),
(96, '', 'Maryam ', 'Awadh', 'Dar', 'Tanzania', '+255', '+255', '', '', 'dataentry', 1),
(97, '', 'Rizik', 'Rashid', 'Unguja', 'Tanzania', '+255', '+255', '', '', 'dataentry', 1),
(98, '', 'Ramadhan', 'Rashid', 'Abu Dhabi', 'UAE', '+9715', '+9715', '', '', 'dataentry', 1),
(99, '', 'Natalia', 'Shayo', 'Dar', 'Tanzania', '+255', '+255', '', '', 'dataentry', 1),
(100, '', 'Iddi', 'Baruan', 'Abu Dhabi', 'UAE', '+9715', '+9715', '', '', 'dataentry', 1),
(101, '', 'Bi Hindu', 'Rashid', 'Unguja', 'Tanzania', '+255784450986', '+255784450986', '', '', 'dataentry', 1),
(102, '', 'Rajab', 'HAji', 'Unguja', 'Tanzania', '+255178883659', '+255718883659', '', '', 'dataentry', 1),
(103, '', 'Salahi', 'Rajab', 'Abu Dhabi', 'UAE', '+9715', '+9715', '', '', 'dataentry', 1),
(104, '', 'Mussa Rajab', 'Haji', 'Unguja', 'Tanzania', '+255715758578', '+255715758578', '', '', 'dataentry', 1),
(105, '', 'Mohamed', 'Hamadi', 'Unguja', 'Tanzania', '+255772089760', '+255772089760', '', '', 'dataentry', 1),
(106, '', 'Rushdah', 'Khamis', 'Unguja', 'Tanzania', '+255776850303', '+255776850303', '', '', 'dataentry', 1),
(107, '', 'Khatib ', 'Omar', 'Abu Dhabi', 'UAE', '+9715', '+9715', '', '', 'dataentry', 1),
(108, '', 'Zuhura', 'Salum', 'Unguja', 'Tanzania', '+255', '+255', '', '', 'dataentry', 1),
(109, '', 'Nufayla', 'Hashoul', 'Unguja', 'Tanzania', '+255', '+255', '', '', 'dataentry', 1),
(110, '', 'Muhammed', 'Naushad', 'Muscat', 'Oman', '+968', '+968', '', '', 'dataentry', 1),
(111, '', 'Karama', 'Said Karama', 'Unguja', 'Tanzania', '+255', '+255', '', '', 'dataentry', 1),
(112, '', 'Khalid', 'Yussuf', 'Dubai', 'UAE', '+9715', '+9715', '', '', 'dataentry', 1),
(113, '', 'Kassim', 'Dar', 'Dar', 'Tanzania', '+255778492023', '+255778492023', '', '', 'dataentry', 1),
(114, '', 'Naila ', 'Al Abry', 'Muscat', 'Oman', '+968', '+968', '', '', 'dataentry', 1),
(115, '', 'Mohamed', 'Mbonde', 'Unguja', 'Tanzania', '+255786234754', '+255786234754', '', '', 'dataentry', 1),
(116, '', 'Walivyo', 'Oman', 'Muscat', 'Oman', '+968', '+968', '', '', 'dataentry', 1),
(117, '', 'Fulaha Kassim', 'Ngorwe', 'Unguja', 'Tanzania', '+255683025712', '+255683025712', '', '', 'dataentry', 1),
(118, '', 'Nassra', 'Mustafa', 'Dar', 'Tanzania', '+255659599797', '+255659599797', '', '', 'dataentry', 1),
(119, '', 'Hemed', 'znz', 'Unguja', 'Tanzania', '+255712305566', '+255712305566', '', '', 'dataentry', 1),
(120, '', 'Nassra', 'Hamdan', 'Muscat', 'Oman', '+968', '+968', '', '', 'dataentry', 1),
(121, '', 'Msellem', 'Abdallah', 'Unguja', 'Tanzania', '+255655853630', '+255655853630', '', '', 'dataentry', 1),
(122, '', 'Fatma ', 'Bakar', 'Unguja', 'Tanzania', '+255717903090', '+255717903090', '', '', 'dataentry', 1),
(123, '', 'Ramadhan', 'Issa', 'Muscat', 'Oman', '+255784578079', '+255784578079', '', '', 'dataentry', 1),
(124, '', 'Hawa', 'Oman', 'Muscat', 'Oman', '+968', '+968', '', '', 'dataentry', 1),
(125, '', 'Visent Joseph', 'Ngitu', 'Dar', 'Tanzania', '+255715667999', '+255715667999', '', '', 'dataentry', 1),
(126, '', 'Farida', 'Oman', 'Muscat', 'Oman', '+968', '+968', '', '', 'dataentry', 1),
(127, '', 'Wema ', 'Juma', 'Unguja', 'Tanzania', '+255776393883', '+255776393883', '', '', 'dataentry', 1),
(128, '', 'Bi Nayla', 'Barwan', 'muscat', 'Oman', '+968', '+968', '', '', 'dataentry', 1),
(129, '', 'Faki', 'Mosi', 'Unguja', 'Tanzania', '+255656995199', '+255656995199', '', '', 'dataentry', 1),
(130, '', 'Farheen', 'Sheikh', 'Dar', 'Tanzania', '+255654464949', '+255654464949', '', '', 'dataentry', 1),
(131, '', 'Anwar Saadat', 'Mohammed', 'Zanzibar', 'Tanzania', '+255712309181', '+255712309181', '', '', 'dataentry', 1),
(132, '', 'Ali ', 'Nassor', 'Unguja', 'Tanzania', '+255', '+255', '', '', 'dataentry', 1),
(133, '', 'Mubaha', 'znz', 'Unguja', 'Tanzania', '+255', '+255', '', '', 'dataentry', 1),
(134, '', 'Swahiba C', 'Kamanga', 'Unguja', 'Tanzania', '+255652292241', '+255652292241', '', '', 'dataentry', 1),
(135, '', 'Mohd', 'Oman', 'Muscat', 'Oman', '+968', '+968', '', '', 'dataentry', 1),
(136, '', 'Ahmed ', 'Hussein', 'znz', 'Tanzania', '+255777416111', '+255777416111', '', '', 'dataentry', 1),
(137, '', 'Khamis', 'Rashid', 'Muscat', 'Oman', '+968', '+968', '', '', 'dataentry', 1),
(138, '', 'Aboud ', 'Mohammed', 'Unguja', 'Tanzania', '+255717903090', '+255717903090', '', '', 'dataentry', 1),
(139, '', 'Zainab', 'Rashid', 'Muscat', 'Oman', '+968', '+968', '', '', 'dataentry', 1),
(140, '', 'Elias', 'Mwaluka', 'Dar', 'Tanzania', '+255742425561', '+255742425561', '', '', 'dataentry', 1),
(141, '', 'Fatma', 'Said', 'Muscat', 'Oman', '+968', '+968', '', '', 'dataentry', 1),
(142, '', 'Frida', 'Kiswaga', 'Dar', 'Tanzania', '+255676767502', '+255676767502', '', '', 'dataentry', 1),
(143, '', 'Sharifa', 'Muhammed', 'Chake Chake', 'Tanzania', '+255772476786', '+255772476786', '', '', 'dataentry', 1),
(144, '', 'Nasser ', 'Abubakar', 'znz', 'Tanzania', '+255778485781', '+255778485781', '', '', 'dataentry', 1),
(145, '', 'Abdully', 'Khaid', 'Unguja', 'Tanzania', '+255713879876', '+255713879876', '', '', 'dataentry', 1),
(146, '', 'Najma', 'Makame', 'Muscat', 'Oman', '+968', '+968', '', '', 'dataentry', 1),
(147, '', 'Oliva ', 'Mwanga', 'Dar', 'Tanzania', '+255679060471', '+255679060471', '', '', 'dataentry', 1),
(148, '', 'Zainab', 'Hamad', 'Muscat', 'Oman', '+968', '+968', '', '', 'dataentry', 1),
(149, '', 'Fauzi', 'Ali', 'Abudhabi', 'UAE', '+977', '+971', '', '', 'dataentry', 1),
(150, '', 'Suleiman', 'Abdallah', 'Abu Dhabi', 'UAE', '+971', '+971', '', '', 'dataentry', 1),
(151, '', 'Asma ', 'said Masoud', 'Chake Chake', 'Tanzania', '+255', '+255', '', '', 'dataentry', 1),
(152, '', 'said', 'Kabogo', 'Dar', 'Tanzania', '+255757482239', '+255757482239', '', '', 'dataentry', 1),
(153, '', 'Mwanaidi', 'Sharjah', 'Sharjah', 'UAE', '+971', '+971', '', '', 'dataentry', 1),
(154, '', 'Hafidh ', 'Issa Yussuf', 'Dar', 'Tanzania', '+255', '+255', '', '', 'dataentry', 1),
(155, '', 'Hafidh', 'Dubai', 'Dubai', 'UAE', '+971', '+971', '', '', 'dataentry', 1),
(156, '', 'Lucy', 'Edward', 'Dar', 'Tanzania', '+255711348624', '+255711348624', '', '', 'dataentry', 1),
(157, '', 'Sanga', 'Jafar', 'Sharjah', 'UAE', '+971', '+971', '', '', 'dataentry', 1),
(158, '', 'Shamsa', 'Kassim', 'Dar', 'Tanzania', '+255714862654', '+255714862654', '', '', 'dataentry', 1),
(159, '', 'Mohamed', 'Ali Mgeni', 'Unguja', 'Tanzania', '+2557188707505', '+2557188707505', '', '', 'dataentry', 1),
(160, '', 'Bakar', 'Hassan', 'Abudhabi', 'UAE', '+971', '+971', '', '', 'dataentry', 1),
(161, '', 'Rehema', 'Simba', 'Dar', 'Tanzania', '+255714388515', '+255714388515', '', '', 'dataentry', 1),
(162, '', 'Mama', 'Zai', 'Abudhabi', 'UAE', '+971', '+971', '', '', 'dataentry', 1),
(163, '', 'Mwanamasudi', 'Mbwana Khalfani', 'Dar', 'Tanzania', '+255677617899', '+255677617899', '', '', 'dataentry', 1),
(164, '', 'Salim', 'Ras lkhaimah', 'Ras lkhaimah', 'UAE', '+971', '+971', '', '', 'dataentry', 1),
(165, '', 'Salim ', 'Abdallah Saleh', 'Dar', 'Tanzania', '+255672769495', '+255672769495', '', '', 'dataentry', 1),
(166, '', 'Sanga', 'Michael', 'Dar', 'Tanzania', '+255759545239', '+255759545239', '', '', 'dataentry', 1),
(167, '', 'Mpaji', 'Hassan Chalula', 'Dar', 'Tanzania', '+255711311928', '+255711311928', '', '', 'dataentry', 1),
(168, '', 'Saleh', 'Mazengo', 'Ras lkhaimah', 'UAE', '+971', '+971', '', '', 'dataentry', 1),
(169, '', 'Rashid ', 'Said', 'Dar', 'Tanzania', '+255789679677', '+255789679677', '', '', 'dataentry', 1),
(170, '', 'Fabian ', 'Chitanda', 'Dubai', 'UAE', '+971', '+971', '', '', 'dataentry', 1),
(171, '', 'Fatma', 'Momo', 'Dar', 'Tanzania', '+255', '+255', '', 'CRDB Bank\r\n0152207472600\r\n', 'dataentry', 1),
(172, '', 'Zena', 'Juma', 'Dar', 'Tanzania', '+255718248989', '+255718248989', '', '', 'dataentry', 1),
(173, '', 'Ramadhan', 'Salehe', 'Dar', 'Tanzania', '+255654167789', '+255654167789', '', '', 'dataentry', 1),
(174, '', 'Juma', 'Saleh', 'Ras lkhaimah', 'UAE', '+971', '+971', '', '', 'dataentry', 1),
(175, '', 'Maryam ', 'Ahmed', 'Dar', 'Tanzania', '+255714285153', '+255714285153', '', '', 'dataentry', 1),
(176, '', 'Abdallah ', 'Hassan', 'Unguja', 'Tanzania', '+255773789601', '+255773789601', '', '', 'dataentry', 1),
(177, '', 'Maryam', 'Kondrad', 'Dar', 'Tanzania', '+255657423912', '+255657423912', '', '', 'dataentry', 1),
(178, '', 'Fabian', 'Kondrad', 'Dubai', 'UAE', '+971', '+971', '', '', 'dataentry', 1),
(179, '', 'Lip ', 'Baharoun', 'Dar', 'Tanzania', '+255653214718', '+255653214718', '', '', 'dataentry', 1),
(180, '', 'Asmahani', 'Abudhabi', 'Abudhabi', 'UAE', '+971', '+971', '', '', 'dataentry', 1),
(181, '', 'Bashir', 'Said', 'Dar', 'Tanzania', '+255714999648', '+255714999648', '', '', 'dataentry', 1);

-- --------------------------------------------------------

--
-- Table structure for table `receivedtransaction`
--

CREATE TABLE IF NOT EXISTS `receivedtransaction` (
  `id` int(255) NOT NULL,
  `sendername` varchar(50) NOT NULL,
  `sendermobnumber` decimal(20,0) NOT NULL,
  `senderloc` varchar(50) NOT NULL,
  `sdate` varchar(100) NOT NULL,
  `senderagent` varchar(50) NOT NULL,
  `receiveragent` varchar(50) NOT NULL,
  `agenttype` varchar(200) NOT NULL,
  `amountsent` varchar(200) NOT NULL,
  `date` varchar(20) NOT NULL,
  `rate` decimal(15,2) NOT NULL,
  `amount` decimal(15,2) NOT NULL,
  `mode` varchar(50) NOT NULL,
  `paymentstatus` varchar(20) NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=90 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `receivedtransaction`
--

INSERT INTO `receivedtransaction` (`id`, `sendername`, `sendermobnumber`, `senderloc`, `sdate`, `senderagent`, `receiveragent`, `agenttype`, `amountsent`, `date`, `rate`, `amount`, `mode`, `paymentstatus`) VALUES
(24, 'Ramadhan Rashid', '9715', 'Abu Dhabi, UAE', '10-02-2018', '1', '19', 'agenttype', '', '', '575.00', '92000.00', 'Cash', 'Pending'),
(32, 'Mohammed Al abry', '968', 'Muscat, Oman', '15-02-2018', '1', '19', 'agenttype', '', '', '575.00', '1000000.00', 'Cash', 'Pending'),
(34, 'Muhammed Naushad', '968', 'Muscat, Oman', '01-02-2018', '', '19', 'agenttype', '', '', '575.00', '273100.00', 'Cash', 'Pending'),
(35, 'Karama Said Karama', '255', 'Unguja, Tanzania', '01-02-2018', '19', '1', 'agenttype', '', '', '575.00', '188025.00', 'Cash', 'Pending'),
(41, 'Naila  Al Abry', '968', 'Muscat, Oman', '03-02-2018', '20', '19', 'agenttype', '', '', '575.00', '54625.00', 'Tigo Pesa', 'Pending'),
(44, 'Naila  Al Abry', '968', 'Muscat, Oman', '04-02-2018', '20', '19', 'agenttype', '', '', '575.00', '1000000.00', 'Cash', 'Pending'),
(48, 'Naila  Al Abry', '968', 'Muscat, Oman', '05-02-2018', '20', '19', 'agenttype', '', '', '575.00', '255327.00', 'Tigo Pesa', 'Pending'),
(49, 'Naila  Al Abry', '968', 'Muscat, Oman', '06-02-2018', '20', '19', 'agenttype', '', '', '575.00', '273200.00', 'Cash', 'Pending'),
(50, 'Naila  Al Abry', '968', 'Muscat, Oman', '06-02-2018', '20', '19', 'agenttype', '', '', '575.00', '273125.00', 'Tigo Pesa', 'Pending'),
(51, 'Muhammed Naushad', '968', 'Muscat, Oman', '07-02-2018', '20', '19', 'agenttype', '', '', '575.00', '518900.00', 'Cash', 'Pending'),
(54, 'Naila  Al Abry', '968', 'Muscat, Oman', '08-02-2018', '20', '19', 'agenttype', '', '', '575.00', '218500.00', 'Cash', 'Pending'),
(55, 'Mohd Oman', '968', 'Muscat, Oman', '08-02-2018', '20', '19', 'agenttype', '', '', '575.00', '163875.00', 'Tigo Pesa', 'Pending'),
(56, 'Muhammed Naushad', '968', 'Muscat, Oman', '08-02-2018', '20', '19', 'agenttype', '', '', '575.00', '218500.00', 'Cash', 'Pending'),
(57, 'Khamis Rashid', '968', 'Muscat, Oman', '10-02-2018', '20', '19', 'agenttype', '', '', '575.00', '273100.00', 'Cash', 'Pending'),
(58, 'Naila  Al Abry', '968', 'Muscat, Oman', '10-02-2018', '20', '19', 'agenttype', '', '', '575.00', '54600.00', 'Cash', 'Pending'),
(59, 'Zainab Rashid', '968', 'Muscat, Oman', '10-02-2018', '20', '19', 'agenttype', '', '', '575.00', '109250.00', 'Tigo Pesa', 'Pending'),
(60, 'Fatma Said', '968', 'Muscat, Oman', '11-02-2018', '20', '19', 'agenttype', '', '', '575.00', '54625.00', 'M-Pesa', 'Pending'),
(61, 'Fatma Said', '968', 'Muscat, Oman', '11-02-2018', '20', '19', 'agenttype', '', '', '575.00', '54625.00', 'Tigo Pose', 'Pending'),
(62, 'Zainab Rashid', '968', 'Muscat, Oman', '11-02-2018', '20', '19', 'agenttype', '', '', '575.00', '1365600.00', 'Cash', 'Pending'),
(63, 'Zainab Rashid', '968', 'Muscat, Oman', '11-02-2018', '20', '19', 'agenttype', '', '', '575.00', '32800.00', 'Cash', 'Pending'),
(64, 'Zainab Rashid', '968', 'Muscat, Oman', '12-02-2018', '20', '19', 'agenttype', '', '', '575.00', '32800.00', 'Cash', 'Pending'),
(65, 'Najma Makame', '968', 'Muscat, Oman', '12-02-2018', '20', '19', 'agenttype', '', '', '575.00', '109250.00', 'Tigo Pesa', 'Pending'),
(66, 'Zainab Hamad', '968', 'Muscat, Oman', '12-02-2018', '20', '19', 'agenttype', '', '', '575.00', '81937.00', 'Cash', 'Pending'),
(67, 'Naila  Al Abry', '968', 'Muscat, Oman', '13-02-2018', '20', '19', 'agenttype', '', '', '575.00', '1092500.00', 'Cash', 'Pending'),
(68, 'Naila  Al Abry', '968', 'Muscat, Oman', '14-02-2018', '20', '19', 'agenttype', '', '', '575.00', '546250.00', 'Tigo Pesa', 'Pending'),
(69, 'Naila  Al Abry', '968', 'Muscat, Oman', '14-02-2018', '20', '19', 'agenttype', '', '', '575.00', '54625.00', 'Tigo Pesa', 'Pending'),
(70, 'Muhammed Naushad', '968', 'Muscat, Oman', '15-02-2015', '20', '19', 'agenttype', '', '', '575.00', '54650.00', 'Cash', 'Pending'),
(71, 'Suleiman Abdallah', '971', 'Abu Dhabi, UAE', '01-02-2018', '17', '19', 'agenttype', '', '', '575.00', '313000.00', 'Ezy Pesa', 'Pending'),
(72, 'Suleiman Abdallah', '971', 'Abu Dhabi, UAE', '02-02-2018', '17', '19', 'agenttype', '', '', '575.00', '262000.00', 'Cash', 'Pending'),
(73, 'Mwanaidi Sharjah', '971', 'Sharjah, UAE', '02-02-2018', '17', '19', 'agenttype', '', '', '575.00', '144000.00', 'M Pesa', 'Pending'),
(74, 'Hafidh Dubai', '971', 'Dubai, UAE', '04-02-2018', '17', '19', 'agenttype', '', '', '575.00', '316000.00', 'Tigo Pesa', 'Pending'),
(75, 'Sanga Jafar', '971', 'Sharjah, UAE', '06-02-2018', '17', '19', 'agenttype', '', '', '575.00', '149500.00', 'Tigo Pesa', 'Pending'),
(76, 'Sanga Jafar', '971', 'Sharjah, UAE', '06-02-2018', '17', '19', 'agenttype', '', '', '575.00', '57500.00', 'Tigo Pesa', 'Pending'),
(77, 'Bakar Hassan', '971', 'Abudhabi, UAE', '07-02-2018', '17', '19', 'agenttype', '', '', '575.00', '190000.00', 'Cash', 'Pending'),
(78, 'Mama Zai', '971', 'Abudhabi, UAE', '08-02-2018', '17', '19', 'agenttype', '', '', '575.00', '300000.00', 'Tigo Pesa', 'Pending'),
(79, 'Salim Ras lkhaimah', '971', 'Ras lkhaimah, UAE', '09-02-2018', '17', '19', 'agenttype', '', '', '575.00', '75000.00', 'Tigo Pesa', 'Pending'),
(80, 'Salim Ras lkhaimah', '971', 'Ras lkhaimah, UAE', '09-02-2018', '17', '19', 'agenttype', '', '', '575.00', '142500.00', 'Tigo Pesa', 'Pending'),
(81, 'Sanga Jafar', '971', 'Sharjah, UAE', '09-02-2018', '17', '19', 'agenttype', '', '', '575.00', '69000.00', 'Tigo Pesa', 'Pending'),
(82, 'Saleh Mazengo', '971', 'Ras lkhaimah, UAE', '09-02-2018', '17', '19', 'agenttype', '', '', '575.00', '2300000.00', 'Tigo Pesa', 'Pending'),
(83, 'Fabian  Chitanda', '971', 'Dubai, UAE', '10-02-2018', '17', '19', 'agenttype', '', '', '575.00', '57500.00', 'Tigo Pesa', 'Pending'),
(84, 'Salim Ras lkhaimah', '971', 'Ras lkhaimah, UAE', '12-02-2018', '17', '19', 'agenttype', '', '', '575.00', '300000.00', 'CRDB Bank', 'Pending'),
(85, 'Sanga Jafar', '971', 'Sharjah, UAE', '12-12-2018', '17', '19', 'agenttype', '', '', '575.00', '57500.00', 'Tigo Pesa', 'Pending'),
(86, 'Juma Saleh', '971', 'Ras lkhaimah, UAE', '13-02-2015', '17', '19', 'agenttype', '', '', '575.00', '57500.00', 'Tigo pesa', 'Pending'),
(87, 'Bakar Hassan', '971', 'Abudhabi, UAE', '14-02-2018', '17', '19', 'agenttype', '', '', '575.00', '30000.00', 'Tigo Pesa', 'Pending'),
(88, 'Bakar Hassan', '971', 'Abudhabi, UAE', '16-02-2018', '17', '19', 'agenttype', '', '', '575.00', '250000.00', 'Cash', 'Pending'),
(89, 'Sanga Jafar', '971', 'Sharjah, UAE', '17-02-2018', '17', '19', 'agenttype', '', '', '575.00', '57500.00', 'Tigo Pesa', 'Pending');

-- --------------------------------------------------------

--
-- Table structure for table `transaction`
--

CREATE TABLE IF NOT EXISTS `transaction` (
  `id` int(255) NOT NULL,
  `sendername` varchar(50) NOT NULL,
  `amount` decimal(15,0) NOT NULL,
  `agentname` varchar(50) NOT NULL,
  `agenttype` varchar(200) NOT NULL,
  `location` varchar(200) NOT NULL,
  `sdate` varchar(100) NOT NULL,
  `receivername` varchar(50) NOT NULL,
  `receivermobnumber` varchar(200) NOT NULL,
  `receiveragent` varchar(50) NOT NULL,
  `receiverlocation` varchar(200) NOT NULL,
  `date` varchar(20) NOT NULL,
  `mode` varchar(50) NOT NULL,
  `rate` decimal(15,2) NOT NULL,
  `buyingrate` decimal(15,2) NOT NULL,
  `buyingmainagent` decimal(15,2) NOT NULL,
  `subbuyingrate` decimal(15,2) NOT NULL,
  `totalearn` decimal(15,2) NOT NULL,
  `agentservices` decimal(15,2) NOT NULL,
  `subagentservices` decimal(15,2) NOT NULL,
  `servicesfordataentry` decimal(15,2) NOT NULL,
  `amounttsz` decimal(15,2) NOT NULL,
  `paymentstatus` varchar(10) NOT NULL,
  `DataEnterny` varchar(100) DEFAULT NULL
) ENGINE=MyISAM AUTO_INCREMENT=97 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `transaction`
--

INSERT INTO `transaction` (`id`, `sendername`, `amount`, `agentname`, `agenttype`, `location`, `sdate`, `receivername`, `receivermobnumber`, `receiveragent`, `receiverlocation`, `date`, `mode`, `rate`, `buyingrate`, `buyingmainagent`, `subbuyingrate`, `totalearn`, `agentservices`, `subagentservices`, `servicesfordataentry`, `amounttsz`, `paymentstatus`, `DataEnterny`) VALUES
(1, 'Fauzia Rabia refence', '2000', '15', 'Super Agent', 'Abu Dhabi, UAE', '04.02.2018', '64', '+255', '19', 'Zanzibar', '', 'cash', '575.00', '590.00', '1180000.00', '580.00', '30000.00', '10000.00', '10000.00', '10000.00', '1150000.00', 'Paid', 'dataentry'),
(2, 'Mohammed Al abry', '1739', '15', 'Super Agent', 'Muscat, Oman', '05-02-2018', '65', '+255774474747 ', '19', 'Unguja ', '', 'Cash', '575.00', '590.00', '1026086.70', '580.00', '26086.95', '8695.65', '8695.65', '8695.65', '999999.75', 'paid', 'dataentry'),
(3, 'Alwyia Baharoon', '2000', '15', 'Super Agent', 'Abu Dhabi, Abu Dhabi', '10-02-2018', '67', '+255778499993 ', '19', 'Unguja ', '', 'Cash', '575.00', '590.00', '1180000.00', '580.00', '30000.00', '10000.00', '10000.00', '10000.00', '1150000.00', 'paid', 'dataentry'),
(4, 'Asha Mahmoud', '226', '15', 'Super Agent', 'Abu Dhabi, UAE', '11-02-2018', '69', '+255767067971 ', '19', 'Unguja ', '', 'Tigo Pesa', '575.00', '590.00', '133393.10', '580.00', '3391.35', '1130.45', '1130.45', '1130.45', '130001.75', 'paid', 'dataentry'),
(5, 'Rabia Alabri', '870', '15', 'Super Agent', 'Abu Dhabi, UAE', '12-02-2018', '73', '+255', '19', 'Unguja', '', 'Cash', '575.00', '590.00', '513300.00', '580.00', '13050.00', '4350.00', '4350.00', '4350.00', '500250.00', 'Pending', 'dataentry'),
(6, 'Salum Mussa', '1425', '1', 'Sub Agent', 'Bureimi, Oman', '01-02-2018', '74', '+255', '19', 'Unguja', '', 'Cash', '575.00', '590.00', '840673.05', '580.00', '21373.04', '7124.35', '7124.35', '7124.35', '819300.00', 'Pending', 'dataentry'),
(8, 'Humoud  Al Abri', '6087', '1', 'Sub Agent', 'Muscat, Oman', '03-02-2018', '27', '+968', '19', 'Unguja', '', 'Cash', '575.00', '590.00', '3591304.35', '580.00', '91304.35', '30434.78', '30434.78', '30434.78', '3500000.00', 'Pending', 'dataentry'),
(9, 'Juma Khamis Ahmada', '600', '1', 'Sub Agent', 'Dubai, UAE', '03-02-2018', '78', '+255776406461', '19', 'Unguja', '', 'Cash', '575.00', '590.00', '354000.00', '580.00', '9000.00', '3000.00', '3000.00', '3000.00', '345000.00', 'Pending', 'dataentry'),
(10, 'Mussa Faki Hamadi', '720', '1', 'Sub Agent', 'Dubai, UAE', '03-02-2018', '21', '+255', '19', 'Unguja', '', 'Cash', '575.00', '590.00', '424800.00', '580.00', '10800.00', '3600.00', '3600.00', '3600.00', '414000.00', 'Pending', 'dataentry'),
(11, 'Shaban Rashid', '500', '1', 'Sub Agent', 'Al Ain, UAE', '04-02-2018', '76', '+255', '19', 'Unguja', '', 'Cash', '575.00', '590.00', '295000.00', '580.00', '7500.00', '2500.00', '2500.00', '2500.00', '287500.00', 'Pending', 'dataentry'),
(12, 'Abas Haji', '226', '1', 'Sub Agent', 'Abu Dhabi, UAE', '04-02-2018', '79', '+255', '19', 'Unguja', '', 'Cash', '575.00', '590.00', '133391.30', '580.00', '3391.30', '1130.43', '1130.43', '1130.43', '130000.00', 'Pending', 'dataentry'),
(13, 'Ally Sharif', '1000', '1', 'Sub Agent', 'Abu Dhabi, UAE', '05-02-2018', '81', '+255', '19', 'Unguja', '', 'Cash', '575.00', '590.00', '590000.00', '580.00', '15000.00', '5000.00', '5000.00', '5000.00', '575000.00', 'Pending', 'dataentry'),
(14, 'Mohamed Abdallah', '200', '1', 'Sub Agent', 'Abu Dhabi, UAE', '06-02-2018', '83', '+255', '19', 'Wete', '', 'Cash', '575.00', '590.00', '118000.00', '580.00', '3000.00', '1000.00', '1000.00', '1000.00', '115000.00', 'Pending', 'dataentry'),
(15, 'Nassor Saleem', '5500', '1', 'Sub Agent', 'Abu Dhabi, UAE', '06-02-2018', '85', '+255', '19', 'Unguja', '', 'Cash', '575.00', '590.00', '3245000.00', '580.00', '82500.00', '27500.00', '27500.00', '27500.00', '3162500.00', 'Pending', 'dataentry'),
(16, 'Twaha Rashid', '3500', '1', 'Sub Agent', 'Abu Dhabi, Tanzania', '06-02-2018', '87', '+255786067973', '19', 'Unguja', '', 'Tigo pesa', '575.00', '590.00', '2065000.00', '580.00', '52500.00', '17500.00', '17500.00', '17500.00', '2012500.00', 'Pending', 'dataentry'),
(17, 'Twaha Rashid', '3200', '1', 'Sub Agent', 'Abu Dhabi, Tanzania', '06-02-2018', '88', '+255717826767', '19', 'Dar', '', 'Tigo pesa', '575.00', '590.00', '1888000.00', '580.00', '48000.00', '16000.00', '16000.00', '16000.00', '1840000.00', 'Pending', 'dataentry'),
(18, 'Twaha Rashid', '100', '1', 'Sub Agent', 'Abu Dhabi, Tanzania', '06-02-2018', '89', '+255713517139', '19', 'Dar', '', 'Tigo pesa', '575.00', '590.00', '59000.00', '580.00', '1500.00', '500.00', '500.00', '500.00', '57500.00', 'Pending', 'dataentry'),
(19, 'Hassan  Suleiman', '3200', '1', 'Sub Agent', 'Abu Dhabi, UAE', '06-02-2018', '90', '+255719253225', '19', 'Unguja', '', 'Tigo pesa', '575.00', '590.00', '1888000.00', '580.00', '48000.00', '16000.00', '16000.00', '16000.00', '1840000.00', 'Pending', 'dataentry'),
(20, 'Khamis Abulani', '87', '1', 'Sub Agent', 'Abu dhabi, UAE', '08-02-2018', '92', '+255', '19', 'Unguja', '', 'Cash', '575.00', '590.00', '51304.35', '580.00', '1304.35', '434.78', '434.78', '434.78', '50000.00', 'Pending', 'dataentry'),
(21, 'Seif Ali', '1000', '1', 'Sub Agent', 'Abu Dhabi, UAE', '08-02-2018', '93', '+255', '19', 'Unguja', '', 'Cash', '575.00', '590.00', '590000.00', '580.00', '15000.00', '5000.00', '5000.00', '5000.00', '575000.00', 'Pending', 'dataentry'),
(22, 'Shamis Said Mohammed', '1099', '1', 'Sub Agent', 'Kuala Lumpur, Malaysia', '09-02-2018', '26', '+255779707870', '19', 'Unguja', '', 'Eazypesa', '575.00', '590.00', '648692.17', '580.00', '16492.17', '5497.39', '5497.39', '5497.39', '632200.00', 'Pending', 'dataentry'),
(23, 'Khamis Abulani', '200', '1', 'Sub Agent', 'Abu dhabi, UAE', '09-02-2018', '96', '+255', '19', 'dar', '', 'Cash', '575.00', '590.00', '118000.00', '580.00', '3000.00', '1000.00', '1000.00', '1000.00', '115000.00', 'Pending', 'dataentry'),
(24, 'Ramadhan Rashid', '160', '1', 'Sub Agent', 'Abu Dhabi, UAE', '10-02-2018', '97', '+255', '19', 'Unguja', '', 'Cash', '575.00', '590.00', '94400.00', '580.00', '2400.00', '800.00', '800.00', '800.00', '92000.00', 'Pending', 'dataentry'),
(25, 'Iddi Baruan', '50', '1', 'Sub Agent', 'Abu Dhabi, UAE', '10-02-2018', '99', '+255746612696', '19', 'Dar', '', 'Tigo pesa', '575.00', '590.00', '29500.00', '580.00', '750.00', '250.00', '250.00', '250.00', '28750.00', 'Pending', 'dataentry'),
(26, 'Iddi Baruan', '205', '1', 'Sub Agent', 'Abu Dhabi, UAE', '10-02-2018', '101', '+255784450986', '19', 'Unguja', '', 'Kwa simu', '575.00', '590.00', '120950.00', '580.00', '3075.00', '1025.00', '1025.00', '1025.00', '117875.00', 'Pending', 'dataentry'),
(27, 'Salahi Rajab', '87', '1', 'Sub Agent', 'Abu Dhabi, UAE', '11-02-2018', '102', '+255718883659', '19', 'Unguja', '', 'Tigo pesa', '575.00', '590.00', '51304.35', '580.00', '1304.35', '434.78', '434.78', '434.78', '50000.00', 'Pending', 'dataentry'),
(28, 'Salahi Rajab', '1413', '1', 'Sub Agent', 'Abu Dhabi, UAE', '11-02-2018', '104', '+255715758578', '19', 'Unguja', '', 'Tigo pesa', '575.00', '590.00', '833695.65', '580.00', '21195.65', '7065.22', '7065.22', '7065.22', '812500.00', 'Pending', 'dataentry'),
(29, 'Khamis Abulani', '70', '1', 'Sub Agent', 'Abu dhabi, UAE', '11-02-2018', '105', '+255772089760', '19', 'Unguja', '', 'Cash', '575.00', '590.00', '41043.48', '580.00', '1043.48', '347.83', '347.83', '347.83', '40000.00', 'Pending', 'dataentry'),
(30, 'Twaha Rashid', '900', '1', 'Sub Agent', 'Abu Dhabi, Tanzania', '12-02-2018', '57', '+9715', '19', 'Unguja', '', 'Cash', '575.00', '590.00', '531000.00', '580.00', '13500.00', '4500.00', '4500.00', '4500.00', '517500.00', 'Pending', 'dataentry'),
(31, 'Masoud Suleiman', '200', '1', 'Sub Agent', 'Abu Dhabi, UAE', '12-02-2018', '106', '+255776850303', '19', 'Unguja', '', 'Cash', '575.00', '590.00', '118000.00', '580.00', '3000.00', '1000.00', '1000.00', '1000.00', '115000.00', 'Pending', 'dataentry'),
(32, 'Mohammed Al abry', '1739', '1', 'Sub Agent', 'Muscat, Oman', '15-02-2018', '66', '+968', '19', 'Unguja', '', 'Cash', '575.00', '590.00', '1026086.96', '580.00', '26086.96', '8695.65', '8695.65', '8695.65', '1000000.00', 'Pending', 'dataentry'),
(33, 'Khatib  Omar', '300', '15', 'Super Agent', 'Abu Dhabi, UAE', '15-02-2018', '108', '+255', '19', 'Unguja', '', 'Cash', '575.00', '590.00', '177000.00', '580.00', '4500.00', '1500.00', '1500.00', '1500.00', '172500.00', 'Pending', 'dataentry'),
(34, 'Muhammed Naushad', '475', '', '', 'Muscat, Oman', '01-02-2018', '109', '+255', '19', 'Zanzibar', '', 'Cash', '575.00', '590.00', '280224.35', '580.00', '7124.35', '2374.78', '2374.78', '2374.78', '273100.00', 'Pending', 'dataentry'),
(35, 'Karama Said Karama', '327', '19', 'Super Agent', 'Unguja, Tanzania', '01-02-2018', '112', '+9715', '1', 'Dubai', '', 'Cash', '575.00', '590.00', '192930.00', '580.00', '4905.00', '1635.00', '1635.00', '1635.00', '188025.00', 'Pending', 'dataentry'),
(36, 'Naila  Al Abry', '950', '20', 'Sub Agent', 'Muscat, Oman', '01-02-2018', '113', '+255778492023', '19', 'Dar', '', 'Cash', '575.00', '590.00', '560500.00', '580.00', '14250.00', '4750.00', '4750.00', '4750.00', '546250.00', 'Pending', 'dataentry'),
(37, 'Walivyo Oman', '380', '20', 'Sub Agent', 'Muscat, Oman', '01-02-2018', '115', '+255786234754', '19', 'Unguja', '', 'Cash', '575.00', '590.00', '224200.00', '580.00', '5700.00', '1900.00', '1900.00', '1900.00', '218500.00', 'Pending', 'dataentry'),
(38, 'Walivyo Oman', '95', '20', 'Sub Agent', 'Muscat, Oman', '01-02-2018', '117', '+255683025712', '19', 'Unguja', '', 'Cash', '575.00', '590.00', '56050.00', '580.00', '1425.00', '475.00', '475.00', '475.00', '54625.00', 'Pending', 'dataentry'),
(39, 'Naila  Al Abry', '190', '20', 'Sub Agent', 'Muscat, Oman', '02-02-2018', '118', '+255659599797', '19', 'Dar', '', 'Tigo Pesa', '575.00', '590.00', '112100.00', '580.00', '2850.00', '950.00', '950.00', '950.00', '109250.00', 'Pending', 'dataentry'),
(40, 'Nassra Hamdan', '190', '20', 'Sub Agent', 'Muscat, Oman', '03-02-2018', '119', '+255712305566', '19', 'Unguja', '', 'Cash', '575.00', '590.00', '112100.00', '580.00', '2850.00', '950.00', '950.00', '950.00', '109250.00', 'Pending', 'dataentry'),
(41, 'Naila  Al Abry', '95', '20', 'Sub Agent', 'Muscat, Oman', '03-02-2018', '121', '+255655853630', '19', 'Unguja', '', 'Tigo Pesa', '575.00', '590.00', '56050.00', '580.00', '1425.00', '475.00', '475.00', '475.00', '54625.00', 'Pending', 'dataentry'),
(42, 'Naila  Al Abry', '380', '20', 'Sub Agent', 'Muscat, Oman', '03-02-2018', '122', '+255717903090', '19', 'Dar', '', 'Cash', '575.00', '590.00', '224200.00', '580.00', '5700.00', '1900.00', '1900.00', '1900.00', '218500.00', 'Pending', 'dataentry'),
(43, 'Hawa Oman', '190', '20', 'Sub Agent', 'Muscat, Oman', '03-02-2018', '123', '+255784578079', '19', 'Unguja', '', 'Airtelmoney', '575.00', '590.00', '112100.00', '580.00', '2850.00', '950.00', '950.00', '950.00', '109250.00', 'Pending', 'dataentry'),
(44, 'Naila  Al Abry', '1739', '20', 'Sub Agent', 'Muscat, Oman', '04-02-2018', '113', '+255778492023', '19', 'Zanzibar', '', 'Cash', '575.00', '590.00', '1026086.96', '580.00', '26086.96', '8695.65', '8695.65', '8695.65', '1000000.00', 'Pending', 'dataentry'),
(45, 'Farida Oman', '380', '', '', 'Muscat, Oman', '04-02-2018', '125', '+255715667999', '19', 'dar', '', 'Tigo Pesa', '575.00', '590.00', '224200.00', '580.00', '5700.00', '1900.00', '1900.00', '1900.00', '218500.00', 'Pending', 'dataentry'),
(46, 'Bi Nayla Barwan', '95', '20', 'Sub Agent', 'muscat, Oman', '05-02-2018', '127', '+255776393883', '19', 'Unguja', '', 'Cash', '575.00', '590.00', '56075.65', '580.00', '1425.65', '475.22', '475.22', '475.22', '54650.00', 'Pending', 'dataentry'),
(47, 'Naila  Al Abry', '475', '20', 'Sub Agent', 'Muscat, Oman', '05-02-2018', '122', '+255656995199', '19', 'dar', '', 'cash', '575.00', '590.00', '280224.35', '580.00', '7124.35', '2374.78', '2374.78', '2374.78', '273100.00', 'Pending', 'dataentry'),
(48, 'Naila  Al Abry', '444', '20', 'Sub Agent', 'Muscat, Oman', '05-02-2018', '129', '+255656995199', '19', 'Unguja', '', 'Tigo Pesa', '575.00', '590.00', '261987.70', '580.00', '6660.70', '2220.23', '2220.23', '2220.23', '255327.00', 'Pending', 'dataentry'),
(49, 'Naila  Al Abry', '475', '20', 'Sub Agent', 'Muscat, Oman', '06-02-2018', '130', '+255654464949', '19', 'Dar', '', 'Cash', '575.00', '590.00', '280326.96', '580.00', '7126.96', '2375.65', '2375.65', '2375.65', '273200.00', 'Pending', 'dataentry'),
(50, 'Naila  Al Abry', '475', '20', 'Sub Agent', 'Muscat, Oman', '06-02-2018', '129', '+255656995199', '19', 'Unguja', '', 'Tigo Pesa', '575.00', '590.00', '280250.00', '580.00', '7125.00', '2375.00', '2375.00', '2375.00', '273125.00', 'Pending', 'dataentry'),
(51, 'Muhammed Naushad', '902', '20', 'Sub Agent', 'Muscat, Oman', '07-02-2018', '109', '+255777637788', '19', 'Zanzibar', '', 'Cash', '575.00', '590.00', '532436.52', '580.00', '13536.52', '4512.17', '4512.17', '4512.17', '518900.00', 'Pending', 'dataentry'),
(52, 'Muhammed Naushad', '380', '20', 'Sub Agent', 'Muscat, Oman', '07-02-2018', '131', '+255712309181', '19', 'Zanzibar', '', 'Cash', '575.00', '590.00', '224200.00', '580.00', '5700.00', '1900.00', '1900.00', '1900.00', '218500.00', 'Pending', 'dataentry'),
(53, 'Mubaha znz', '535', '19', 'Super Agent', 'Unguja, Tanzania', '08-02-2018', '133', '+9715', '1', 'Dubai', '', 'Cash', '575.00', '590.00', '315650.00', '580.00', '8025.00', '2675.00', '2675.00', '2675.00', '307625.00', 'Pending', 'dataentry'),
(54, 'Naila  Al Abry', '380', '20', 'Sub Agent', 'Muscat, Oman', '08-02-2018', '129', '+255717903090', '19', 'Dar', '', 'Cash', '575.00', '590.00', '224200.00', '580.00', '5700.00', '1900.00', '1900.00', '1900.00', '218500.00', 'Pending', 'dataentry'),
(55, 'Mohd Oman', '285', '20', 'Sub Agent', 'Muscat, Oman', '08-02-2018', '134', '+255652292241', '19', 'Unguja', '', 'Tigo Pesa', '575.00', '590.00', '168150.00', '580.00', '4275.00', '1425.00', '1425.00', '1425.00', '163875.00', 'Pending', 'dataentry'),
(56, 'Muhammed Naushad', '380', '20', 'Sub Agent', 'Muscat, Oman', '08-02-2018', '109', '+255777637788', '19', 'znz', '', 'Cash', '575.00', '590.00', '224200.00', '580.00', '5700.00', '1900.00', '1900.00', '1900.00', '218500.00', 'Pending', 'dataentry'),
(57, 'Khamis Rashid', '475', '20', 'Sub Agent', 'Muscat, Oman', '10-02-2018', '137', '+255777416111', '19', 'znz', '', 'Cash', '575.00', '590.00', '280224.35', '580.00', '7124.35', '2374.78', '2374.78', '2374.78', '273100.00', 'Pending', 'dataentry'),
(58, 'Naila  Al Abry', '95', '20', 'Sub Agent', 'Muscat, Oman', '10-02-2018', '122', '+255717903090', '19', 'dar', '', 'Cash', '575.00', '590.00', '56024.35', '580.00', '1424.35', '474.78', '474.78', '474.78', '54600.00', 'Pending', 'dataentry'),
(59, 'Zainab Rashid', '190', '20', 'Sub Agent', 'Muscat, Oman', '10-02-2018', '138', '+255712405323', '19', 'Unguja', '', 'Tigo Pesa', '575.00', '590.00', '112100.00', '580.00', '2850.00', '950.00', '950.00', '950.00', '109250.00', 'Pending', 'dataentry'),
(60, 'Fatma Said', '95', '20', 'Sub Agent', 'Muscat, Oman', '11-02-2018', '140', '+255742425561', '19', 'Dar', '', 'M-Pesa', '575.00', '590.00', '56050.00', '580.00', '1425.00', '475.00', '475.00', '475.00', '54625.00', 'Pending', 'dataentry'),
(61, 'Fatma Said', '95', '20', 'Sub Agent', 'Muscat, Oman', '11-02-2018', '142', '+255676767502', '19', 'Dar', '', 'Tigo Pose', '575.00', '590.00', '56050.00', '580.00', '1425.00', '475.00', '475.00', '475.00', '54625.00', 'Pending', 'dataentry'),
(62, 'Zainab Rashid', '2375', '20', 'Sub Agent', 'Muscat, Oman', '11-02-2018', '143', '+255772476786', '19', 'Chake Chake', '', 'Cash', '575.00', '590.00', '1401224.35', '580.00', '35624.35', '11874.78', '11874.78', '11874.78', '1365600.00', 'Pending', 'dataentry'),
(63, 'Zainab Rashid', '57', '20', 'Sub Agent', 'Muscat, Oman', '11-02-2018', '144', '+255778485781', '19', 'znz', '', 'Cash', '575.00', '590.00', '33655.65', '580.00', '855.65', '285.22', '285.22', '285.22', '32800.00', 'Pending', 'dataentry'),
(64, 'Zainab Rashid', '57', '20', 'Sub Agent', 'Muscat, Oman', '12-02-2018', '144', '+255778485781', '19', 'znz', '', 'Cash', '575.00', '590.00', '33655.65', '580.00', '855.65', '285.22', '285.22', '285.22', '32800.00', 'Pending', 'dataentry'),
(65, 'Najma Makame', '190', '20', 'Sub Agent', 'Muscat, Oman', '12-02-2018', '146', '+255713879876', '19', 'Unguja', '', 'Tigo Pesa', '575.00', '590.00', '112100.00', '580.00', '2850.00', '950.00', '950.00', '950.00', '109250.00', 'Pending', 'dataentry'),
(66, 'Zainab Hamad', '142', '20', 'Sub Agent', 'Muscat, Oman', '12-02-2018', '147', '+255679060471', '19', 'Dar', '', 'Cash', '575.00', '590.00', '84074.49', '580.00', '2137.49', '712.50', '712.50', '712.50', '81937.00', 'Pending', 'dataentry'),
(67, 'Naila  Al Abry', '1900', '20', 'Sub Agent', 'Muscat, Oman', '13-02-2018', '113', '+255778492023', '19', 'Dar', '', 'Cash', '575.00', '590.00', '1121000.00', '580.00', '28500.00', '9500.00', '9500.00', '9500.00', '1092500.00', 'Pending', 'dataentry'),
(68, 'Naila  Al Abry', '950', '20', 'Sub Agent', 'Muscat, Oman', '14-02-2018', '129', '+255656995199', '19', 'Unguja', '', 'Tigo Pesa', '575.00', '590.00', '560500.00', '580.00', '14250.00', '4750.00', '4750.00', '4750.00', '546250.00', 'Pending', 'dataentry'),
(69, 'Naila  Al Abry', '95', '20', 'Sub Agent', 'Muscat, Oman', '14-02-2018', '121', '+255655853630', '19', 'unguja', '', 'Tigo Pesa', '575.00', '590.00', '56050.00', '580.00', '1425.00', '475.00', '475.00', '475.00', '54625.00', 'Pending', 'dataentry'),
(70, 'Muhammed Naushad', '95', '20', 'Sub Agent', 'Muscat, Oman', '15-02-2015', '109', '+255777637788', '19', 'Unguja', '', 'Cash', '575.00', '590.00', '56075.65', '580.00', '1425.65', '475.22', '475.22', '475.22', '54650.00', 'Pending', 'dataentry'),
(71, 'Suleiman Abdallah', '544', '17', 'Sub Agent', 'Abu Dhabi, UAE', '01-02-2018', '149', '+255779602533', '19', 'UngujA', '', 'Ezy Pesa', '575.00', '590.00', '321165.22', '580.00', '8165.22', '2721.74', '2721.74', '2721.74', '313000.00', 'Pending', 'dataentry'),
(72, 'Suleiman Abdallah', '456', '17', 'Sub Agent', 'Abu Dhabi, UAE', '02-02-2018', '151', '+255', '19', '+255', '', 'Cash', '575.00', '590.00', '268834.78', '580.00', '6834.78', '2278.26', '2278.26', '2278.26', '262000.00', 'Pending', 'dataentry'),
(73, 'Mwanaidi Sharjah', '250', '17', 'Sub Agent', 'Sharjah, UAE', '02-02-2018', '152', '+255757482239', '19', 'Dar', '', 'M Pesa', '575.00', '590.00', '147756.52', '580.00', '3756.52', '1252.17', '1252.17', '1252.17', '144000.00', 'Pending', 'dataentry'),
(74, 'Hafidh Dubai', '550', '17', 'Sub Agent', 'Dubai, UAE', '04-02-2018', '154', '+255717368187', '19', 'Dar', '', 'Tigo Pesa', '575.00', '590.00', '324243.48', '580.00', '8243.48', '2747.83', '2747.83', '2747.83', '316000.00', 'Pending', 'dataentry'),
(75, 'Sanga Jafar', '260', '17', 'Sub Agent', 'Sharjah, UAE', '06-02-2018', '156', '+255711348624', '19', 'Dar', '', 'Tigo Pesa', '575.00', '590.00', '153400.00', '580.00', '3900.00', '1300.00', '1300.00', '1300.00', '149500.00', 'Pending', 'dataentry'),
(76, 'Sanga Jafar', '100', '17', 'Sub Agent', 'Sharjah, UAE', '06-02-2018', '158', '+255714862654', '19', 'dar', '', 'Tigo Pesa', '575.00', '590.00', '59000.00', '580.00', '1500.00', '500.00', '500.00', '500.00', '57500.00', 'Pending', 'dataentry'),
(77, 'Bakar Hassan', '330', '17', 'Sub Agent', 'Abudhabi, UAE', '07-02-2018', '159', '+2557188707505', '19', 'Unguja', '', 'Cash', '575.00', '590.00', '194956.52', '580.00', '4956.52', '1652.17', '1652.17', '1652.17', '190000.00', 'Pending', 'dataentry'),
(78, 'Mama Zai', '522', '17', 'Sub Agent', 'Abudhabi, UAE', '08-02-2018', '161', '+255714388515', '19', 'Dar', '', 'Tigo Pesa', '575.00', '590.00', '307826.09', '580.00', '7826.09', '2608.70', '2608.70', '2608.70', '300000.00', 'Pending', 'dataentry'),
(79, 'Salim Ras lkhaimah', '130', '17', 'Sub Agent', 'Ras lkhaimah, UAE', '09-02-2018', '163', '+255677617899', '19', 'Dar', '', 'Tigo Pesa', '575.00', '590.00', '76956.52', '580.00', '1956.52', '652.17', '652.17', '652.17', '75000.00', 'Pending', 'dataentry'),
(80, 'Salim Ras lkhaimah', '248', '17', 'Sub Agent', 'Ras lkhaimah, UAE', '09-02-2018', '165', '+255672769495', '19', 'Dar', '', 'Tigo Pesa', '575.00', '590.00', '146217.39', '580.00', '3717.39', '1239.13', '1239.13', '1239.13', '142500.00', 'Pending', 'dataentry'),
(81, 'Sanga Jafar', '120', '17', 'Sub Agent', 'Sharjah, UAE', '09-02-2018', '166', '+255759545239', '19', 'Dar', '', 'Tigo Pesa', '575.00', '590.00', '70800.00', '580.00', '1800.00', '600.00', '600.00', '600.00', '69000.00', 'Pending', 'dataentry'),
(82, 'Saleh Mazengo', '4000', '17', 'Sub Agent', 'Ras lkhaimah, UAE', '09-02-2018', '167', '+255711311928', '19', 'Dar', '', 'Tigo Pesa', '575.00', '590.00', '2360000.00', '580.00', '60000.00', '20000.00', '20000.00', '20000.00', '2300000.00', 'Pending', 'dataentry'),
(83, 'Fabian  Chitanda', '100', '17', 'Sub Agent', 'Dubai, UAE', '10-02-2018', '170', 'Chitanda', '19', 'dar', '', 'Tigo Pesa', '575.00', '590.00', '59000.00', '580.00', '1500.00', '500.00', '500.00', '500.00', '57500.00', 'Pending', 'dataentry'),
(84, 'Salim Ras lkhaimah', '522', '17', 'Sub Agent', 'Ras lkhaimah, UAE', '12-02-2018', '171', '+255', '19', 'dar', '', 'CRDB Bank', '575.00', '590.00', '307826.09', '580.00', '7826.09', '2608.70', '2608.70', '2608.70', '300000.00', 'Pending', 'dataentry'),
(85, 'Sanga Jafar', '100', '17', 'Sub Agent', 'Sharjah, UAE', '12-12-2018', '172', '+255718248989', '19', 'dar', '', 'Tigo Pesa', '575.00', '590.00', '59000.00', '580.00', '1500.00', '500.00', '500.00', '500.00', '57500.00', 'Pending', 'dataentry'),
(86, 'Juma Saleh', '100', '17', 'Sub Agent', 'Ras lkhaimah, UAE', '13-02-2015', '173', '+255654167789', '19', 'Dar', '', 'Tigo pesa', '575.00', '590.00', '59000.00', '580.00', '1500.00', '500.00', '500.00', '500.00', '57500.00', 'Pending', 'dataentry'),
(87, 'Bakar Hassan', '52', '17', 'Sub Agent', 'Abudhabi, UAE', '14-02-2018', '175', '+255714285153', '19', 'Dar', '', 'Tigo Pesa', '575.00', '590.00', '30782.61', '580.00', '782.61', '260.87', '260.87', '260.87', '30000.00', 'Pending', 'dataentry'),
(88, 'Bakar Hassan', '435', '17', 'Sub Agent', 'Abudhabi, UAE', '16-02-2018', '176', '+255773789601', '19', 'Unguja', '', 'Cash', '575.00', '590.00', '256521.74', '580.00', '6521.74', '2173.91', '2173.91', '2173.91', '250000.00', 'Pending', 'dataentry'),
(89, 'Sanga Jafar', '100', '17', 'Sub Agent', 'Sharjah, UAE', '17-02-2018', '172', '+255718248989', '19', 'dar', '', 'Tigo Pesa', '575.00', '590.00', '59000.00', '580.00', '1500.00', '500.00', '500.00', '500.00', '57500.00', 'Pending', 'dataentry'),
(90, 'Fabian Kondrad', '100', '17', 'Sub Agent', 'Dubai, UAE', '17-02-2017', '177', '+255657423912', '19', 'Dar', '', 'Tigo Pesa', '575.00', '590.00', '59000.00', '580.00', '1500.00', '500.00', '500.00', '500.00', '57500.00', 'Pending', 'dataentry'),
(91, 'Asmahani Abudhabi', '70', '17', 'Sub Agent', 'Abudhabi, UAE', '20-02-2018', '179', '+255653214718', '19', 'Dar', '', 'Tigo Pesa', '575.00', '590.00', '41043.48', '580.00', '1043.48', '347.83', '347.83', '347.83', '40000.00', 'Pending', 'dataentry'),
(92, 'Sanga Jafar', '41', '17', 'Sub Agent', 'Sharjah, UAE', '20-02-2018', '172', '255718248989', '19', 'Dar', '', 'Tigo Pesa', '575.00', '590.00', '24113.04', '580.00', '613.04', '204.35', '204.35', '204.35', '23500.00', 'Pending', 'dataentry'),
(93, 'Mama Zai', '2261', '17', 'Sub Agent', 'Abudhabi, UAE', '20-02-2018', '181', '+255714999648', '19', 'Dar', '', 'Tigo Pesa', '575.00', '590.00', '1333913.04', '580.00', '33913.04', '11304.35', '11304.35', '11304.35', '1300000.00', 'Pending', 'dataentry'),
(94, 'Shaban Rashid', '500', '19', 'Super Agent', 'Al Ain, UAE', '08/03/2018', '16', '', '15', '', '', '', '576.00', '590.00', '295000.00', '580.00', '7000.00', '2333.33', '2333.33', '2333.33', '288000.00', 'Paid', 'mohdali'),
(95, 'Bint Dahal', '200', '22', 'Dataentry', 'Abu Dhabi, UAE', '08/03/2018', '14', '85214632112', '1', 'test', '', 'Cash', '575.00', '590.00', '118000.00', '580.00', '3000.00', '1000.00', '1000.00', '1000.00', '115000.00', 'Paid', 'mohdali'),
(96, 'Abdallah Juma', '300', '1', 'Sub Agent', 'Abu Dhabi, UAE', '08/03/2018', '29', '8541266339', '18', 'znz test', '', 'cash', '575.00', '590.00', '177000.00', '580.00', '4500.00', '1500.00', '1500.00', '1500.00', '172500.00', 'Paid', 'mohdali');

-- --------------------------------------------------------

--
-- Table structure for table `transactiontz`
--

CREATE TABLE IF NOT EXISTS `transactiontz` (
  `Id` int(20) NOT NULL,
  `sendername` varchar(200) NOT NULL,
  `agentname` varchar(200) NOT NULL,
  `agenttype` varchar(200) NOT NULL,
  `agentlocation` varchar(200) NOT NULL,
  `amountinsh` varchar(200) NOT NULL,
  `amountinaed` varchar(200) NOT NULL,
  `receivername` varchar(200) NOT NULL,
  `receiverlocation` varchar(200) NOT NULL,
  `receivermobnumber` varchar(200) NOT NULL,
  `receiveragent` varchar(200) NOT NULL,
  `mode` varchar(200) NOT NULL,
  `paymentstatus` varchar(200) NOT NULL,
  `sdate` varchar(200) NOT NULL,
  `rate` varchar(200) NOT NULL,
  `buyingmanagent` varchar(200) NOT NULL,
  `buyingrate` varchar(200) NOT NULL,
  `agentservices` varchar(200) NOT NULL,
  `servicesfordataentry` varchar(200) NOT NULL,
  `subagentservices` varchar(200) NOT NULL,
  `subbuyingrate` varchar(200) NOT NULL,
  `totalearn` varchar(200) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(255) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `usertype` varchar(20) NOT NULL,
  `firstname` varchar(50) DEFAULT NULL,
  `lastname` varchar(50) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `location` varchar(200) NOT NULL,
  `active` int(1) NOT NULL DEFAULT '1'
) ENGINE=MyISAM AUTO_INCREMENT=28 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `usertype`, `firstname`, `lastname`, `email`, `location`, `active`) VALUES
(1, 'admin', 'admin@123', 'admin', NULL, NULL, NULL, '', 1),
(18, 'super', 'super@123', 'Super Agent', NULL, NULL, NULL, '', 1),
(19, 'dataentry', 'entry@018', 'dataentry', NULL, NULL, NULL, '', 1),
(21, 'agentznz', 'znz@123', 'agent', 'sample', 'sample', NULL, 'zanzibar', 1),
(27, 'mohdali', 'abc123', 'Dataentry', 'Mohd', 'Ali', 'alyafyfreal@gmail.com', '', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `agents`
--
ALTER TABLE `agents`
  ADD PRIMARY KEY (`id`), ADD UNIQUE KEY `id` (`id`), ADD UNIQUE KEY `username` (`username`);

--
-- Indexes for table `customers`
--
ALTER TABLE `customers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `receivedtransaction`
--
ALTER TABLE `receivedtransaction`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `transaction`
--
ALTER TABLE `transaction`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `transactiontz`
--
ALTER TABLE `transactiontz`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`), ADD UNIQUE KEY `id` (`id`), ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `agents`
--
ALTER TABLE `agents`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=24;
--
-- AUTO_INCREMENT for table `customers`
--
ALTER TABLE `customers`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=182;
--
-- AUTO_INCREMENT for table `receivedtransaction`
--
ALTER TABLE `receivedtransaction`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=90;
--
-- AUTO_INCREMENT for table `transaction`
--
ALTER TABLE `transaction`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=97;
--
-- AUTO_INCREMENT for table `transactiontz`
--
ALTER TABLE `transactiontz`
  MODIFY `Id` int(20) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=28;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
