<?php
	include("../include/config.php");
	$id=$_GET['id'];
	$f=$_GET['f'];
	
	if($f==1) {
		$sql = mysqli_query($db,"UPDATE agents SET active = 1 WHERE id = '$id'");
		header("Location: view-agents.php");
	}
	
	else if($f==2) {
		$sql = mysqli_query($db,"UPDATE agents SET active = 0 WHERE id = '$id'");
		header("Location: view-agents.php");
	}
	else if($f==3) {
		$sql = mysqli_query($db,"DELETE FROM agents WHERE id = '$id'");
		header("Location: view-agents.php");
	}
	else if($f==4) {
		$sql = mysqli_query($db,"UPDATE customers SET active = 1 WHERE id = '$id'");
		header("Location: view-customers.php");
	}
	
	else if($f==5) {
		$sql = mysqli_query($db,"UPDATE customers SET active = 0 WHERE id = '$id'");
		header("Location: view-customers.php");
	}
	else if($f==6) {
		$sql = mysqli_query($db,"DELETE FROM customers WHERE id = '$id'");
		header("Location: view-customers.php");
	}
	else if($f==7) {
		$sql = mysqli_query($db,"DELETE FROM transaction WHERE id = '$id'");
		header("Location: view-transaction.php");
	}
	else if($f==8) {
		$sql = mysqli_query($db,"DELETE FROM receivedtransaction WHERE id = '$id'");
		header("Location: view-received-transaction.php");
	}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>MoneyTran</title>
</head>
<body>
<?php include("./header.php"); ?><br />
<section style="background-color:#FFF" align="center"><br /><br /><br /><br /><br /><br /><br /><br />
	<div align="center" style="vertical-align:middle !important">
    	<img src="images/loading.gif" alt="Loading"  />
    </div>
</section>
<?php include("../footer.php"); ?><br />
</body>
</html>