<?php 
include("../header.php");

?>
<!doctype html>
    <html lang="en">
    <head>
      <meta charset="UTF-8">
      <title>Delete Transaction</title>
      <link href="../style/style.css" rel="stylesheet" type="text/css" />
    </head>
    <body style="background-color:#CCC;">
    <br/> <br/> <br/> 
    <center> 
    <h2 align="center" class="input-group form-signin-heading" style="margin:center;"><font color="red"> Deleting..... </font> </h2><br/> Please wait </center> 
      <?php
      

      //execute the SQL query and return records
	  $agentname = $login_session;
	  $sql = "SELECT * FROM transaction WHERE agentname = '$agentname'";
      $result = mysqli_query($db,$sql) or die("Error: ".mysqli_error($db));
      ?>
     
    <div class="container">
    <form class="form-signin" method="POST">
    
    <?php
    	 $id=$_GET['id'];
		  $f=$_GET['f'];
		if($f==12) {
		
			$query = "DELETE FROM `transaction` WHERE `id`=$id";
			$result = mysqli_query($db,$query) or die("Error: ".mysqli_error($db));
			if($result === TRUE){
				$smsg = "Transaction Deleted Successfully! Please wait while we Redirect you to Index Page.";
				header( "refresh:5; url=view-transaction.php" );
			}
			else $fmsg = "Transaction couldnt be Deleted! Try Again";
			}
	?>
    <br/><br/> <br/><br/><br/> <br/><br/><br/> <br/><br/><br/> <br/><br/><br/> <br/><br/><br/><br/> <br/><br/> <br/>
  
    </form>
    </div>
    </body>
    </html>
    <?php include("../footer.php"); ?>