<html>
   
   <head>
      <title>SuperAgent Page</title>
      <link href="../style/style.css" rel="stylesheet" type="text/css">
   </head>   
<body bgcolor = "#FFFFFF">
<?php
   include('../header.php');
?>
<div id="content">
   <a href="view-agents.php">View Agents</a>
   <a href="view-customers.php">View Customers</a>
   <a href="view-transaction.php">View Transactions</a>
   <a href="view-received-transaction.php">View Received Transactions</a>
   <a href="password-change.php">Change Password</a>
   <a href="../logout.php">Log Out</a>
  </div>
<?php
   include('../footer.php');
?>
</body>
</html>