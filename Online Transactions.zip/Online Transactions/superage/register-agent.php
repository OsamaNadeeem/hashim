<?php 
include("../header.php");
error_reporting(0);
function randomPassword() {
    $alphabet = "abcdefghijklmnopqrstuwxyzABCDEFGHIJKLMNOPQRSTUWXYZ0123456789";
    $pass = array(); //remember to declare $pass as an array
    $alphaLength = strlen($alphabet) - 1; //put the length -1 in cache
    for ($i = 0; $i < 8; $i++) {
        $n = rand(0, $alphaLength);
        $pass[] = $alphabet[$n];
    }
    return implode($pass); //turn the array into a string
}

if(isset($_POST['submit'])) {
      // If the values are posted, insert them into the database.
    	$firstname = isset($_POST['firstname']) ? $_POST['firstname'] : '';
		$lastname = isset($_POST['lastname']) ? $_POST['lastname'] : '';
		$city = isset($_POST['city']) ? $_POST['city'] : '';
		//$state = isset($_POST['state']) ? $_POST['state'] : '';
		$country = isset($_POST['country']) ? $_POST['country'] : '';
		$mobnumber1 = isset($_POST['mobnumber1']) ? $_POST['mobnumber1'] : '';
		$mobnumber2 = isset($_POST['mobnumber2']) ? $_POST['mobnumber2'] : 'NULL';
		$email = isset($_POST['email']) ? $_POST['email'] : 'NULL';
		$agenttype = isset($_POST['agenttype']) ? $_POST['agenttype'] : 'NULL';
 		
		$username = str_replace("",strtolower($firstname . $lastname));
		$password = randomPassword();
 
        $query = "INSERT INTO agents (firstname, lastname, username, city, country, mobnumber1, mobnumber2, email, agenttype, active) VALUES ('$firstname',  '$lastname', '$username', '$city', '$country', '$mobnumber1', '$mobnumber2', '$email', '$agenttype', default)";
        $result = mysqli_query($db, $query) or die("Error: ".mysqli_error($db));
		
		$query2 = mysqli_query($db,"INSERT INTO users (username, password, usertype, firstname, lastname, email, active) VALUES ('$username', '$password', '$agenttype', '$firstname', '$lastname', '$email', default)") or die("Error: ".mysqli_error($db));
        if($result === TRUE){
            $smsg = "Agent Account Created Successfully! Please wait while we Redirect you to Index Page.";
			$toEmail = $_POST["email"];
			$subject = "You have been registered to MoneyTran!";
			$content = "You have been registered to MoneyTran as an Agent. Here is your <br /> Username : '$email' Password : '$password' MoneyTran Thank You With Regards MoneyTran Admin";
			$mailHeaders = "From: Admin\r\n";
			if(mail($toEmail, $subject, $content, $mailHeaders)) {
				$smsg = $smsg . "Mail Sent Successfully";
header( "refresh:5; url=index.php" );
			}
			
        }else{
            $fmsg ="Agent Account Couldn't be Created. Try Again!";
        }
   }

?>
<html>
<head>
<title>Register Agent</title>
<link href="../style/style.css" rel="stylesheet" type="text/css" />
</head>
<body style="background-color:#CCC !important">
<h2 align="center" class="input-group form-signin-heading" style="margin-left:100px;">Agent Details</h2>
<div class="container">
              <form class="form-signin" method="POST">
       <?php if(isset($smsg)){ ?><div class="alert alert-success" role="alert"> <?php echo $smsg; ?> </div><?php } ?>
       <?php if(isset($fmsg)){ ?><div class="alert alert-danger" role="alert"> <?php echo $fmsg; ?> </div><?php } ?>
     
                
             <div class="input-group">
              
              <label align="center">Agent Name</label>
              <input type="text" name="firstname" placeholder="First Name" required autofocus>
                <input type="text" name="lastname" placeholder="Last Name" required>
            </div>
            <div class="input-group">
              
              <label align="center">Agent Type</label>
              <select style="width:350px;" name="agenttype" required>
              	  <option value="" selected disabled>Select Agent Type</option>
                  <option value="Super Agent">Super Agent</option>
                  <option value="Sub Agent">Sub Agent</option>
               </select>
            </div>
            <div class="input-group">
              
              <label align="center">Location</label>
              <input type="text" name="city" class="form-control" placeholder="City" required>
              <input type="text" name="country" class="form-control" placeholder="Country" required>
            </div>
            <div class="input-group">
                <h5 align="center" class="form-signin-heading"><b>Mobile Number</b></h5>
                <input type="text" name="mobnumber1" class="form-control" placeholder="Mobile Number" required>
                </div>
             <div class="input-group">
                <label align="center">Alternate Mobile Number</label>
                <input type="text" name="mobnumber2" class="form-control" placeholder="Alternate Mobile Number">
             </div>
             <div class="input-group">
                <label for="inputEmail" align="center">Email address</label>
                <input type="email" name="email" id="inputEmail" class="form-control" placeholder="Email address" required>
              </div>  
                <a href="#" id="agentcom" style="text-align:center;">Agent Commission Details</a>
                <button type="submit" name="submit" >Submit</button>
                <a href="../admin/index.php" style="text-align:center">Back</a>
              </form>
        </div>
      
   </body>
</html>
<?php include("../footer.php"); ?>