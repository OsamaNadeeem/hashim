<?php
	include('../header.php');
   if(isset($_POST['submit'])) {
      // If the values are posted, insert them into the database.
    	$firstname = isset($_POST['firstname']) ? $_POST['firstname'] : '';
		$lastname = isset($_POST['lastname']) ? $_POST['lastname'] : '';
		$city = isset($_POST['city']) ? $_POST['city'] : '';
		//$state = isset($_POST['state']) ? $_POST['state'] : '';
		$country = isset($_POST['country']) ? $_POST['country'] : '';
		$mobnumber1 = isset($_POST['mobnumber1']) ? $_POST['mobnumber1'] : '';
		$mobnumber2 = isset($_POST['mobnumber2']) ? $_POST['mobnumber2'] : 'NULL';
		$email = isset($_POST['email']) ? $_POST['email'] : 'NULL';
		$bankdetails = isset($_POST['bankdetails']) ? $_POST['bankdetails'] : 'NULL';
		$agentname = $login_session;
 
        $query = "INSERT INTO customers (firstname,  lastname, city, country, mobnumber1, mobnumber2, email, bankdetails, agentname, active) VALUES ('$firstname',  '$lastname', '$city', '$country', '$mobnumber1', '$mobnumber2', '$email', '$bankdetails', '$agentname', default)";
        $result = mysqli_query($db, $query) or die("Error: ".mysqli_error($db));
        if($result === TRUE){
            $smsg = "Customer Details Saved Successfully! Please wait while we Redirect you.";
			header( "refresh:5; url=../agent/send.php?firstname=$firstname&lastname=$lastname&city=$city&country=$country&mobnumber1=$mobnumber1" );
        }else{
            $fmsg ="Customer Details Couldn't be Saved. Try Again!";
        }
   }

?>
       
<html>
<head>
<title>Customer Details</title>
<link href="../style/style.css" rel="stylesheet" type="text/css" />
</head>
<body style="background-color:#CCC !important">
<h2 align="center" class="input-group form-signin-heading" style="margin-left:100px;">Customer Details</h2>
<div class="container">

		<input onClick="document.getElementById('existingcust').disabled = false; document.getElementById('registercust').disabled = true;" type="radio" name="type" checked="checked">Existing Customer?
        
        <select id="existingcust" name="to_user" class="form-control" onChange="location = this.options[this.selectedIndex].value;" required>
            <option value="pick" selected disabled>Select Customer</option>
            <?php
            $sql = mysqli_query($db, "SELECT * From customers");
            $row = mysqli_num_rows($sql);
            while ($row = mysqli_fetch_array($sql)){
            echo "<option value='exist.php?id=". $row['id'] ."'>" .$row['firstname'] ." ". $row['lastname']."</option>" ;
            }
            ?>
        </select>
        
        <input onClick="document.getElementById('existingcust').disabled = true; document.getElementById('registercust').disabled = false;" type="radio" name="type" value="customurl">New Customer?

         <form class="form-signin" method="POST" id="registercust">
       <?php if(isset($smsg)){ ?><div class="alert alert-success" role="alert"> <?php echo $smsg; ?> </div><?php } ?>
       <?php if(isset($fmsg)){ ?><div class="alert alert-danger" role="alert"> <?php echo $fmsg; ?> </div><?php } ?>
     
             <div class="input-group">
              <label align="center">Customer Name</label>
              <input type="text" name="firstname" class="form-control" placeholder="First Name" required autofocus>
             
              <input type="text" name="lastname" class="form-control" placeholder="Last Name" required>
            </div>
            <div class="input-group">
              
              <label align="center">Location</label>
              <input type="text" name="city" class="form-control" placeholder="City" required>
              <input type="text" name="country" class="form-control" placeholder="Country" required>
            </div>
            <div class="input-group">
                <h5 align="center" class="form-signin-heading"><b>Mobile Number</b></h5>
                <input type="text" name="mobnumber1" class="form-control" placeholder="Mobile Number" required>
            </div>     
                <div class="input-group">
                 <label align="center">Alternate Mobile Number</label>
                <input type="text" name="mobnumber2" class="form-control" placeholder="Alternate Mobile Number">
             </div>    
                <div class="input-group">
                <label for="inputEmail" align="center">Email address</label>
                <input type="email" name="email" id="inputEmail" class="form-control" placeholder="Email address">
              
                <label align="center">Bank Details</label>
                <textarea class="form-control" rows="4" cols="60" name="bankdetails" placeholder="Enter Bank Details"></textarea> 
               </div>
                <button type="submit" name="submit">Submit</button>
                <a href="../superage/index.php">Back</a>
              </form>
        </div>

   </body>
</html>