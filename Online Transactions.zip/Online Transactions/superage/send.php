<?php
	include('../header.php');
   
   error_reporting(0);

	/*function convertCurrency( $from, $to,$amount){
		$data = file_get_contents("https://finance.google.com/finance/converter?a=$amount&from=$from&to=$to");
		preg_match("/<span class=bld>(.*)<\/span>/",$data, $converted);
		$converted = preg_replace("/[^0-9.]/", "", $converted[1]);
		return number_format(round($converted, 3),2);
	}
           
					// change amount according to your needs
					$amount =1;
					// change From Currency according to your needs
					$from_Curr ="AED";
					// change To Currency according to your needs
					$to_Curr ="TZS";
					$rate=convertCurrency($from_Curr, $to_Curr, $amount);
					// Print outout
				*/
				
					if(isset($_POST['submit'])) {
						
		
	 	$name = $_GET['firstname'] . ' ' . $_GET['lastname'];
	    $senderlocation = $_GET ['city'] .', ' . $_GET ['country'];	
		$sendermobnumber = $_GET ['mobnumber1'];
		  	
		// If the values are posted, insert them into the database.
		$sendername = $name;
		$amount = isset($_POST['amount']) ? $_POST['amount'] : '';
		$agentname = $login_session;
		$location = isset($_POST['location']) ? $_POST['location'] : '';
		$sdate = isset($_POST['sdate']) ? $_POST['sdate'] : '';
		$receivername = isset($_POST['receivername']) ? $_POST['receivername'] : '';
		$receivermobnumber = isset($_POST['receivermobnumber']) ? $_POST['receivermobnumber'] : '';		
		$receiveragent = isset($_POST['receiveragent']) ? $_POST['receiveragent'] : '';
		$receiverlocation = isset($_POST['receiverlocation']) ? $_POST['receiverlocation'] : '';
		$mode = isset($_POST['mode']) ? $_POST['mode'] : '';
		$rate = isset($_POST['rate']) ? $_POST['rate'] : '';
		
		// Culculations
		$amounttsz = $amount * $rate;
		$buyingrate =590;
		$buyingmainagent = $buyingrate * $amount;
		
		$subbuyingrate = 580;
				
		$totalearn = $buyingmainagent - $amounttsz;
		
		
		$agentservices = $totalearn/3;
		$subagentservices = $totalearn/3;
		$servicesfordataentry = $totalearn/3;
		
		$paymentstatus = isset($_POST['paymentstatus']) ? $_POST['paymentstatus'] : '';
 
		$query = "INSERT INTO transaction (sendername, amount, agentname, location, sdate, receivername, receivermobnumber, receiveragent, receiverlocation,  mode, rate, buyingrate, buyingmainagent, subbuyingrate, totalearn, agentservices, subagentservices, servicesfordataentry, amounttsz, paymentstatus) VALUES ('$sendername', '$amount', '$agentname', '$location', '$sdate','$receivername', '$receivermobnumber', '$receiveragent', '$receiverlocation', '$mode', '$rate','$buyingrate', '$buyingmainagent', '$subbuyingrate', '$totalearn', '$agentservices', '$subagentservices', '$servicesfordataentry', '$amounttsz', '$paymentstatus') ";
		$result = mysqli_query($db, $query) or die("Error: ".mysqli_error($db));
		
		$query2 = mysqli_query($db, "INSERT INTO receivedtransaction (sendername, sendermobnumber, senderloc, sdate, senderagent, receiveragent, rate, amount, mode, paymentstatus) VALUES ('$sendername', '$sendermobnumber', '$location', '$sdate', '$agentname', '$receiveragent', '$rate', '$amounttsz', '$mode', '$paymentstatus')") or die("Error: ".mysqli_error($db));
		
		$email = mysqli_query($db, "SELECT email FROM agents WHERE username='$receiveragent'")or die("Error: ".mysqli_error($db));
		
		
		if($result === TRUE){
			$smsg = "Money Sent Successfully! Amount in TZS : '.$amounttsz'";
			$smsg = $smsg . "Money Received from '$agentname' by '$sendername'. Please wait while we Redirect you to Index Page.";
			$toEmail = $email;
			$subject = "Money Received from '$agentname' by '$sendername'";
			$content = "User '$receivername' has Received Money sent from '$location' by '$sendername'. Please MoneyTran for More Details.";
			$mailHeaders = "From: Agent\r\n";
			if(mail($toEmail, $subject, $content, $mailHeaders)) {
				$smsg = $smsg ."Mail Sent Successfully!";
			}
			header( "refresh:5; url=index.php" );
		}else{
			$fmsg ="Money Sending Failed. Try Again!";
		}
   }
?>      
<html>
<head>
<title>Receiver Details</title>
<link href="../style/style.css" rel="stylesheet" type="text/css" />
<script type="text/javascript">
function updateInput(ish){
    document.getElementById("buyingmain").value = ish * <?php echo $rate + 25 ?>;
	document.getElementById("amountrec").value = ish * <?php echo $rate ?>;
	document.getElementById("totalearn").value = (ish * <?php echo $rate +25 ?>) - (ish * <?php echo $rate ?>);
	document.getElementById("agentser").value = ((ish * <?php echo $rate +25 ?>) - (ish * <?php echo $rate ?>))/3;
	document.getElementById("subagentser").value = ((ish * <?php echo $rate +25 ?>) - (ish * <?php echo $rate ?>))/3;
	document.getElementById("dataentry").value = ((ish * <?php echo $rate +25 ?>) - (ish * <?php echo $rate ?>))/3;
}
</script>
</head>
<body style="background-color:#CCC !important">
<h2 align="center" class="input-group form-signin-heading" style="margin-left:100px;">Receiver Details</h2>
<div class="container">
			  <form class="form-signin" method="POST" >
	   <?php if(isset($smsg)){ ?><div class="alert alert-success" role="alert"> <?php echo $smsg; ?> </div><?php } ?>
	   <?php if(isset($fmsg)){ ?><div class="alert alert-danger" role="alert"> <?php echo $fmsg; ?> </div><?php } ?>
	          <div class="input-group">   
			  <label align="center">Sender Name</label>
			  <input type="text" name="sendername" class="form-control" value="<?php echo $name = $_GET['firstname'] . ' ' . $_GET['lastname']; ?>" disabled>
			  </div>
              <div class="input-group">
              <label class="amount" align="center">Amount in AED</label>
			  <input type="text" name="amount" id="amount" class="form-control" placeholder="Amount" onchange="updateInput(this.value)" required>
			  </div>
              <div class="input-group">
             <div class="input-group">
              <label align="center">Agent Name</label>
			  <input type="text" name="agentname" class="form-control" value="<?php echo $login_session; ?>" disabled>
			  </div>
			 
			 
			  </div>
             <div class="input-group">
              <label align="center">Location</label>
			  <input type="text" name="location" class="form-control" value="<?php echo $senderlocation = $_GET ['city'] .', ' . $_GET ['country']; ?>" disabled>
				</div>
	
	      <div class="input-group">
				<label align="center">Date</label>
				<input type="text" name="sdate" class="form-control" placeholder="Date" required>
				</div>
		
                <div class="input-group">
				<label align="center">Receiver Name</label>
				<input type="text" name="receivername" class="form-control" placeholder="Receiver Name" required>
				</div>
                <div class="input-group">
                <label align="center">Receiver Mobile Number</label>
				<input type="text" name="receivermobnumber" class="form-control" placeholder="Receiver Mobile Number">
				</div>
                <div class="input-group">
                <label align="center">Receiver Location</label>
				<input type="text" name="receiverlocation" class="form-control" placeholder="Receiver Location">
                </div>
                <div class="input-group">
                <label align="center">Receiver Agent Name</label>
			  <input type="text" name="receiveragent" class="form-control" placeholder="Receiver Agent">
			  	</div>
                <div class="input-group">
                <label align="center">Mode of Payment</label>
				<input type="text" name="mode" class="form-control" placeholder="Mode of Payment">
				</div>
                <div class="input-group">
                <label align="center">Rate</label>
				<input type="text" name="rate" class="form-control" placeholder="Rate">
				</div>
                <div class="input-group">
                <label align="center">Amount to be Recieved</label>
				<input id="amountrec" type="text" name="amounttsz" class="form-control" placeholder="Amount" value="<?php echo $amounttsz ?>" disabled>
				</div>
                <div class="input-group">
               
                
                
                <div class="input-group">
                <label align="center">Payment Status</label>
				<select name="paymentstatus" style="width:350px" required>
                	<option value="Pending" selected disabled>Select Payment</option>
                    <option value="Paid">Paid</option>
                    <option value="Pending">Pending</option>
                </select>
				</div>
                <button  type="submit" name="submit">Send</button>
				<a href="../superage/index.php">Back</a>
			  </form>
		</div>
	  
   </body>
</html>