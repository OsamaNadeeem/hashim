<?php 
include("../header.php");
$id=$_GET['id'];
$u=$_GET['u'];
$msg="";

if(isset($_POST['update'])) {
	if($u==1) {
		  // If the values are posted, insert them into the database.
			$firstname = isset($_POST['firstname']) ? $_POST['firstname'] : '';
			$lastname = isset($_POST['lastname']) ? $_POST['lastname'] : '';
			$username = isset($_POST['username']) ? $_POST['username'] : '';
			$city = isset($_POST['city']) ? $_POST['city'] : '';
			//$state = isset($_POST['state']) ? $_POST['state'] : '';
			$country = isset($_POST['country']) ? $_POST['country'] : '';
			$mobnumber1 = isset($_POST['mobnumber1']) ? $_POST['mobnumber1'] : '';
			$mobnumber2 = isset($_POST['mobnumber2']) ? $_POST['mobnumber2'] : 'NULL';
			$email = isset($_POST['email']) ? $_POST['email'] : 'NULL';
			$agenttype = isset($_POST['agenttype']) ? $_POST['agenttype'] : 'NULL';
			$query1 = "UPDATE `agents` SET `firstname` = '$firstname', `lastname` = '$lastname', `username` = '$username', `city` = '$city', `country` = '$country', `mobnumber1` = '$mobnumber1', `mobnumber2` = '$mobnumber2', `email` = '$email', `agenttype` = '$agenttype' WHERE `agents`.`id` = $id;
	";
			$result1 = mysqli_query($db, $query1) or die("Error: ".mysqli_error($db));
			if($result1===TRUE) {
				header("Location: view-agents.php");
			} else {
				$msg = "Coudln't Update the Details! Try Again!";
			}
	} else {
			$firstname = isset($_POST['firstname']) ? $_POST['firstname'] : '';
			$lastname = isset($_POST['lastname']) ? $_POST['lastname'] : '';
			$city = isset($_POST['city']) ? $_POST['city'] : '';
			//$state = isset($_POST['state']) ? $_POST['state'] : '';
			$country = isset($_POST['country']) ? $_POST['country'] : '';
			$mobnumber1 = isset($_POST['mobnumber1']) ? $_POST['mobnumber1'] : '';
			$mobnumber2 = isset($_POST['mobnumber2']) ? $_POST['mobnumber2'] : 'NULL';
			$email = isset($_POST['email']) ? $_POST['email'] : 'NULL';
			$bankdetails = isset($_POST['bankdetails']) ? $_POST['bankdetails'] : 'NULL';
			$agentname = isset($_POST['agentname']) ? $_POST['agentname'] : 'NULL';
			$query2 = "UPDATE `customers` SET `firstname` = '$firstname', `lastname` = '$lastname', `city` = '$city', `country` = '$country', `mobnumber1` = '$mobnumber1', `mobnumber2` = '$mobnumber2', `email` = '$email', `bankdetails` = '$bankdetails', `agentname` = '$agentname' WHERE `customers`.`id` = $id;
	";
			$result2 = mysqli_query($db, $query2) or die("Error: ".mysqli_error($db));
			if($result2===TRUE) {
				header("Location: view-customers.php");
			} else {
				$msg = "Coudln't Update the Details! Try Again!";
			}
	}
}
?>
<!doctype html>
    <html lang="en">
    <head>
      <meta charset="UTF-8">
      <title>Update Details</title>
    </head>
    <body style="background-color:#CCC;">
    <h2 align="center" class="input-group form-signin-heading" style="margin-left:100px;">Update Details</h2> 
      <?php
	  
      //execute the SQL query and return records
	  $agentname = $login_session;
	  if($u==1)
	  	$sql = "SELECT * FROM agents WHERE id = '$id'";
      else
	  	$sql = "SELECT * FROM customers WHERE id = '$id'";
	  $result = mysqli_query($db,$sql) or die("Error: ".mysqli_error($db));
      ?>
      <div>
      <div><?php echo $msg; ?></div>
      <form method="post">
      <table align="center" style="width:auto !important; padding:3 !important;">
      <?php if($u==1) { ?>
      <thead>
        <tr>
          <th>ID</th> 
          <th>First Name</th>
          <th>Last Name</th>
          <th>Username</th>
          <th>City</th>
          <th>Country</th>
          <th>Mobile Number</th>
          <th>Alternate Mobile Number</th>
          <th>Email</th>
          <th>Agent Type</th>
		  <th>Active</th>                                       
        </tr>
      </thead>
      <tbody>
        <?php
          while( $row = mysqli_fetch_assoc($result) ){
		?>
            <tr>
              <td><?php echo $row['id']; ?></td>
              <td><input type="text" name="firstname" style="width:200px" value="<?php echo $row['firstname']; ?>" style="padding:0 !important; margin:0 !important" ></td>
               <td><input type="text" name="lastname" style="width:200px" value="<?php echo $row['lastname']; ?>" ></td>
			  <td><input type="text" name="username" style="width:200px" value="<?php echo $row['username']; ?>" ></td>
              <td><input type="text" name="city" style="width:200px" value="<?php echo $row['city'] ; ?>" ></td>
			  <td><input type="text" name="country" style="width:200px" value="<?php echo $row['country']; ?>" ></td>
			  <td><input type="text" name="mobnumber1" style="width:140px" value="<?php echo $row['mobnumber1'] ; ?>" ></td>
			  <td><input type="text" name="mobnumber2" style="width:140px" value="<?php echo $row['mobnumber2'] ; ?>" ></td>
			  <td><input type="text" name="email" style="width:250px" value="<?php echo $row['email'] ; ?>" ></td>
              <td><select style="width:200px;" name="agenttype">
              	  <?php if($row['agenttype'] == "Super Agent") { ?>
                  <option value="Super Agent" selected>Super Agent</option>
                  <option value="Sub Agent">Sub Agent</option>
                  <?php } else {?>
                  <option value="Super Agent">Super Agent</option>
                  <option value="Sub Agent" selected>Sub Agent</option>
                  <?php } ?>
                 </select>
              </td>
			  <td><?php echo $row['active'] ; ?></td>
        </tr>
 <?php } ?>
      </tbody>
      <?php } else { ?>
      <thead>
        <tr>
          <th>ID</th>
          <th>First Name</th>
          <th>Last Name</th>
          <th>City</th>
          <th>Country</th>
          <th>Mobile Number</th>
          <th>Alternate Mobile Number</th>
          <th>Email</th>
          <th>Bank Details</th>
          <th>Agent Name</th>
		  <th>Active</th>                                        
        </tr>
      </thead>
      <tbody>
        <?php
          while( $row = mysqli_fetch_assoc($result) ){
	    ?> 
        <tr>
              <td><?php echo $row['id']; ?></td>
              <td><input type="text" name="firstname" style="width:100px" value="<?php echo $row['firstname']; ?>" ></td>
          
              <td><input type="text" name="lastname" style="width:100px" value="<?php echo $row['lastname']; ?>" ></td>
			  <td><input type="text" name="city" style="width:100px" value="<?php echo $row['city']; ?>" ></td>
			  <td><input type="text" name="country" style="width:100px" value="<?php echo $row['country']; ?>" ></td>
			  <td><input type="text" name="mobnumber1" style="width:140px" value="<?php echo $row['mobnumber1']; ?>" ></td>
			  <td><input type="text" name="mobnumber2" style="width:140px" value="<?php echo $row['mobnumber2']; ?>" ></td>
			  <td><input type="text" name="email" style="width:250px" value="<?php echo $row['email']; ?>" ></td>
			  <td><input type="text" name="bankdetails" style="width:200px" value="<?php echo $row['bankdetails']; ?>" ></td>
			  <td><input type="text" name="agentname" style="width:100px" value="<?php echo $row['agentname']; ?>" ></td>
			  <td><?php echo $row['active']; ?></td>
            "?>
        </tr>
 <?php } ?>
      </tbody>
      <?php } ?>
      
    </table>
    <button type="update" value="Update" name="update" style="margin-left:500px;" >Update</button>
    </form>
    </div>
    <div id="content">
    <div class="input-group">
    <?php if($u==1) { ?>
    <a href="../admin/view-agents.php">Back</a>
    <?php } else { ?>
    <a href="../admin/view-customers.php">Back</a>
    <?php } ?>
    </div>
    </div>
    </body>
    </html>
    <?php include("../footer.php"); ?>