<?php 
include("../header.php");
error_reporting(0);
$totalamountsent="";
$totalrate="";
$totalamountz="";
?>
<!doctype html>
    <html lang="en">
    <head>
      <meta charset="UTF-8">
      <title>Received Transactions</title>
    </head>
    <body style="background-color:#CCC;">
    <h2 align="center" class="input-group form-signin-heading" style="margin-left:100px;">Remote</h2>
      <?php
      

      //execute the SQL query and return records
	  $agentname = $login_session;
	  $sql = "SELECT * FROM receivedtransaction";
      $result = mysqli_query($db,$sql) or die("Error: ".mysqli_error($db));
      ?>
       <table align="center" style="width:100%;">
      <div>
     
      <thead  >
        <tr>
          <th>ID</th>
          <th>Date</th>
          <th>Sender Name</th>
          <th>Sender Mobile Number</th>
          <th>Sender Location</th>
          <th>Sender Agent</th>
          <th>Receiver Agent</th>
           <th>Amount in AED</th>
           <th>Rate</th>
          <th>Amount Received</th>    
          <th>Mode of Payment</th> 
          <th>Payment Status</th>

        </tr>
      </thead>
      <tbody>
        <?php
          while( $row = mysqli_fetch_assoc($result) ){
            echo
            "<tr>
              <td>{$row['id']}</td>
              <td>{$row['sdate']}</td>
              <td>{$row['sendername']}</td>
              <td>{$row['sendermobnumber']}</td>
              <td>{$row['senderloc']}</td>
              <td>{$row['senderagent']}</td>
              <td>{$row['receiveragent']}</td> 
                          <td>{$row['amountsent']}</td>  
			  <td>{$row['rate']}</td>
			  <td>{$row['amount']}</td>			  
			  <td>{$row['mode']}</td>
			  <td>{$row['paymentstatus']}</td>
             "?>
        	 <?php " " ."\n            ";
			$totalamountsent = $totalamountsent + $row['amountsent'];
			
			$totalamountz = $totalamountz + $row['amount'];
          }
  ?>
      </tbody>
     	<tfoot>
            <tr>
             <td colspan="7"><b>Total</td>
              <td><b><?php echo $totalamountsent;?></td>
               <td colspan="1">-</td>
               <td><b><?php echo $totalamountz;?></td>
            </tr>
  		</tfoot>
    </table>
    </div>
    <div id="content">
    <div class="input-group">
    <a href="view-transaction.php">View Transaction</a>
    <a href="../superage/index.php">Back</a>
     </div>
    </div>
    </body>
    </html>
    <?php include("../footer.php"); ?>