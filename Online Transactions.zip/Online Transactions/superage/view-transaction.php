<?php 
include("../header.php");
error_reporting(0);
$totalamount="";
$totalrate="";
$totalamounttzs=""; 
$totalbuyingrate="";
$totalbuyingmainagent="";
$totalsubbuyingrate="";
$totaltotalearn="";
$totalagentservices="";
$totalsubagentservices="";
$totalservicesfordataentry="";
?>
<!doctype html>
    <html lang="en">
    <head>
      <meta charset="UTF-8">
      <title>Sent Transactions</title>
    </head>
    <body style="background-color:#CCC;">
    <h2 align="center" class="input-group form-signin-heading" style="margin-left:100px;">View Transactions</h2> 
      <?php
      

      //execute the SQL query and return records
	  $agentname = $login_session;
	  $sql = "SELECT *,FORMAT(amounttsz,3) as amounttsz1 FROM transaction";
      $result = mysqli_query($db,$sql) or die("Error: ".mysqli_error($db));
      ?>
      <div>
      <table align="center" style="width:100%;">
      <thead>
        <tr>
          <th>ID</th>
           <th>Date</th>
             <th>Agent Name</th>
          <th>Sender Name</th>
         
        
          <th>Location</th>
         
          <th>Receiver Name</th>
          <th>Receiver Mobile Number</th>
          <th>Receiver Agent</th>
          <th>Receiver Location</th>
          <th>Mode of Payment</th>
           <th>Amount in AED</th>
          <th>Rate</th>
          <th>Amount in TZS</th> 
          <th>Payment Status</th>
          <th>Agent Services </th>  
                                
        </tr>
      </thead>
      <tbody>
        <?php
          while( $row = mysqli_fetch_assoc($result) ){
            echo
            "<tr>
              <td>{$row['id']}</td>
              <td>{$row['sdate']}</td>
              <td>{$row['sendername']}</td>
              <td>{$row['amount']}</td>
              <td>{$row['agentname']}</td>
              <td>{$row['location']}</td>
             
              <td>{$row['receivername']}</td> 
			  <td>{$row['receivermobnumber']}</td>
			  <td>{$row['receiveragent']}</td>
			  <td>{$row['receiverlocation']}</td>
			  <td>{$row['mode']}</td>
			  <td>{$row['rate']}</td>
			  <td>{$row['amounttsz1']   }</td>
			  <td>{$row['paymentstatus']}</td>
			   <td>{$row['agentservices']}</td>
			              "?>
			
            </tr> <?php " " ."\n            ";
			$totalamount=$totalamount+$row['amount'];
			$totalrate=$totalrate+$row['rate'];
			$totalamounttzs=$totalamounttzs+$row['amounttsz']; 
			$totalbuyingrate=$totalbuyingrate+$row['buyingrate'];
			$totalbuyingmainagent=$totalbuyingmainagent+$row['buyingmainagent'];
			$totalsubbuyingrate=$totalsubbuyingrate+$row['subbuyingrate'];
			$totaltotalearn=$totaltotalearn+$row['totalearn'];
			$totalagentservices=$totalagentservices+$row['agentservices'];
			$totalsubagentservices=$totalsubagentservices+$row['subagentservices'];
			$totalservicesfordataentry=$totalservicesfordataentry+$row['servicesfordataentry'];
          }
  ?>
      </tbody>
      <tfoot>
            <tr>
              <td colspan="2">Total</td>
              <td><b> <?php echo $totalamount;?></b> </td>
              <td colspan="9">-</td>
			 
              <td><b> <?php echo $totalamounttzs;?></b> </td>
              <td colspan="1">-</td>
              <td><b> <?php echo $totalagentservices;?></b> </td>
            </tr>
  		</tfoot>
    </table>
    </div>
    <div id="content">
    <div class="input-group">
    <a href="view-received-transaction.php">View Received Transaction</a>
    <a href="../superage/index.php">Back</a>
    </div>
    </div>
    </body>
    </html>
    <?php include("../footer.php"); ?>